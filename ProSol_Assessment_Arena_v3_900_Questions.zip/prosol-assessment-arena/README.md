# ProSol Consulting | Assessment Arena v3.0

**Trainer-controlled live assessments for managers and assistant managers.** Six subjects, 900 multiple-choice questions, unified admin, participant and presentation interfaces, real-time polling, server-controlled exam starts and time limits, private marking, and persistent result storage.

## What's new in v3

- **50 Easy questions added to every category**, for 150 questions per category and **900 total**.
- Trainer can choose **Easy, Medium, Hard or any combination**; questions are distributed approximately evenly among selected levels. One level allows up to 50 questions, two levels up to 100, and all three up to 150.
- All *static page headings* use Title Case, with an updated navy, teal and white design, more consistent spacing, accessibility focus states and mobile answer layouts. Assessment-question text intentionally retains its original punctuation and capitalization.
- More robust round state: an expired assessment is recognized as finished without needing a second trainer action. Trainers can release scores after the deadline.
- Concurrency-controlled state changes, rollback after failed saves, private trainer answer keys, and persistent results using **PostgreSQL** (Neon, Supabase, or another compatible host).
- Local JSON-file mode remains available for offline testing. **Production now refuses to start without `DATABASE_URL`** unless persistent local storage is explicitly acknowledged.
- Downloadable results and trainer question bank are available only from logged-in admin endpoints. Never share this code archive or trainer CSV with participants.

## Assessment Bank

| Category | Easy | Medium | Hard | Total |
|---|---:|---:|---:|---:|
| Verbal Intelligence Test | 50 | 50 | 50 | 150 |
| Non Verbal Intelligence Test | 50 | 50 | 50 | 150 |
| Mechanical Aptitude Test | 50 | 50 | 50 | 150 |
| Mathematical Test | 50 | 50 | 50 | 150 |
| Focus Attention Test | 50 | 50 | 50 | 150 |
| English Vocabulary Test | 50 | 50 | 50 | 150 |
| **Total** | **300** | **300** | **300** | **900** |

Each item contains four choices, one server-side answer index, an explanation and a difficulty label. Nonverbal questions contain symbol-grid diagrams. **These are training items, not independently validated psychometric instruments.** Have qualified reviewers check language, difficulty and ambiguity before high-stakes decisions.

## Run Locally

Prerequisites: **Node.js 20.6+**, npm and a browser.

1. Extract the ZIP to a folder. Open a terminal in the `prosol-assessment-arena` directory.
2. Run `npm install` to install the Postgres driver (Internet connection required for installation).
3. Copy `.env.example` to `.env`.
4. Set a unique `ADMIN_PASSWORD` of at least 12 characters. Replace the example placeholder with your own strong password.
5. Start with `npm run dev`.
6. Open `http://localhost:3000`, `http://localhost:3000/admin.html`, `http://localhost:3000/participant.html`, or `http://localhost:3000/console.html`.

Local mode stores data in `data/assessment-state.json`. The path can be customized with `ASSESSMENT_DATA_FILE`.

### Running an Assessment

1. Open **Admin Control** and sign in. Select one of the six categories, check the desired **Difficulty Levels**, set the number of questions and duration (1–120 minutes), and select **Save Round Settings**.
2. Open **Participant Console** on each participant's phone or laptop; participants register by full name and one of five groups. They wait in the lobby until the trainer starts.
3. The trainer clicks **Authorize & Start Assessment**. Questions then appear on participants' devices. Late registrations are rejected.
4. Participants answer at their own pace; each answer is persisted by the server immediately. At least 70% must be answered before voluntary manual submission. A timer expiry finalizes the saved responses automatically.
5. The trainer can close a round early, review individual answers privately, export scores, and release group results to the presentation console and individual scores to participants.
6. Select **Prepare Next Round** to open the lobby for the next category. Prior participant scores are retained in the administrator's results export.

**Note:** One server supports **one active round** at a time. A participant name is not a verified identity; trainer oversight remains necessary.

## Free Cloud Deployment: Render + Neon

This is a useful **no-cost pilot setup**, not a no-downtime production SLA:

1. Create a free [Neon](https://neon.com/) PostgreSQL project. Open **Connection Details**, select the **pooled** connection string, and copy the URI (including `sslmode=require`).
2. Put the app in a **private GitHub repository**. Do not commit `.env`; this repository contains the private answer bank, so do not make it public.
3. Create a [Render](https://render.com/) **Web Service** from the repository. Select **Free** instance. Choose Node, build command `npm install --omit=dev` and start command `npm start`. The provided `render.yaml` can also create the web service.
4. Add protected environment variables in Render:

   | Name | Value |
   |---|---|
   | `DATABASE_URL` | Neon **pooled** PostgreSQL URI (secret) |
   | `ADMIN_PASSWORD` | Your private 12+ character password |
   | `NODE_ENV` | `production` |

5. Deploy; check `https://YOUR-APP.onrender.com/api/health`. The response reports `storage: "postgres"` when connected. Use `/admin.html` to log in, and send the participant URL to all devices.
6. **Export results after every session**, keep CSV backups somewhere private, and test full joining/scoring/restart before a live workshop.

### Limits of Free Tiers (checked October 2026)

- **Neon** Free presently includes up to **1 GB storage per project**, subject to compute and other plan limits. See [Neon plans](https://neon.com/pricing) and [the October 2026 announcement](https://neon.com/blog/neon-free-plan-1-gb-per-project).
- **Render Free** web services go idle after **15 minutes without incoming requests** and can take about one minute to start up. **Their local files are not durable**—therefore you must set `DATABASE_URL` to preserve results.
- **Supabase Free** is another compatible PostgreSQL option, presently offering **500 MB database** and possible pauses after **seven days of low activity**.
- **Do not select Render's free PostgreSQL for permanent records**; its free databases currently expire **30 days** after creation.
- The current Postgres adapter stores the single-instance application's active-and-historical state in one JSONB row. It is suitable for small pilot sessions; for high concurrency, implement normalized tables, background jobs, load testing and multiple-instance coordination. **Do not run multiple replicas against the same app state.**

### Keeping Results When Moving from v2 Local JSON

If you already ran v2 using a persistent `data/assessment-state.json`, retain an offline copy and export CSV results before switching databases. Cloud mode starts with an empty state unless existing data is explicitly migrated.

With `DATABASE_URL` set, **while the cloud app is not running**, import an existing JSON file into a new/empty database:

```bash
node scripts/migrate_json_to_postgres.js data/assessment-state.json
```

The migration utility refuses to overwrite a database containing participant history.

## Project Files

| File / folder | Purpose |
|---|---|
| `index.html` | Welcome / role navigation |
| `admin.html` | Password-protected trainer dashboard |
| `participant.html` | Registration, waiting room, timed quiz and results |
| `console.html` | Public projection / presentation view |
| `assest/css/styles.css` | Shared visual system and responsive styling (folder name preserved for compatibility) |
| `assest/js/app.js` | Interface behavior / API client |
| `server.js` | Live sessions, security, scoring and persistence |
| `private/questions-bank.json` | **Private** question text, answers and explanations |
| `private/questions-for-trainers.csv` | **Private** trainer answer key |
| `scripts/build_bank.py`, `scripts/add_easy.py` | Reproducible 900-question generator |
| `scripts/test_api.js`, `scripts/test_edgecases.js` | Automated live API, concurrency and recovery checks |
| `scripts/migrate_json_to_postgres.js` | Safe import of an earlier JSON results file |
| `render.yaml` | Example Render web-service configuration |
| `DESIGN_REVIEW.md` | Critical review, current improvements, gaps and risks |

## Testing

```bash
npm test
node scripts/test_edgecases.js
```

The test suite verifies login, unauthorized access, early/late registration, six categories, all difficulty options, answer-key privacy, submissions, score publication, CSV exports, timer expiry, concurrent writes, restarts and save failures.

**What hasn't been verified yet:** a real Neon/Supabase connection using your credentials, full end-to-end layout testing in Chrome/Safari on physical devices, and realistic performance at high simultaneous participant counts. The app cannot be guaranteed completely bug-free without those deployment-specific checks; run a pilot rehearsal before formal use.
