'use strict';
const {spawn}=require('node:child_process');const fs=require('node:fs');const os=require('node:os');const path=require('node:path');const assert=require('node:assert/strict');
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'prosol-test-'));
const port=17000+Math.floor(Math.random()*10000);const url=`http://127.0.0.1:${port}`;const password='TestOnlyPassword_12345!';
const child=spawn(process.execPath,['server.js'],{cwd:path.resolve(__dirname,'..'),env:{...process.env,PORT:String(port),NODE_ENV:'development',ADMIN_PASSWORD:password,ASSESSMENT_DATA_FILE:path.join(tmp,'assessment-state.json')},stdio:['ignore','pipe','pipe']});
const categories=['Verbal Intelligence Test','Non Verbal Intelligence Test','Mechanical Aptitude Test','Mathematical Test','Focus Attention Test','English Vocabulary Test'];
let cookie='';let passed=0;
const variants=[['Easy'],['Medium'],['Hard'],['Easy','Medium'],['Medium','Hard'],['Easy','Medium','Hard']];
async function request(p,method='GET',data=null,token=''){
  const response=await fetch(url+p,{method,headers:{...(data?{'Content-Type':'application/json'}:{}),...(cookie?{Cookie:cookie}:{}),...(token?{'X-Participant-Token':token}:{})},...(data?{body:JSON.stringify(data)}:{})});
  const payload=response.headers.get('content-type')?.includes('json')?await response.json():await response.text();return {response,data:payload};
}
async function assertStatus(path,method,body,status,token=''){
  const r=await request(path,method,body,token);assert.equal(r.response.status,status,`${method} ${path}: ${JSON.stringify(r.data)}`);passed++;return r;
}
async function run(){
 try{
  let started=false;for(let i=0;i<60;i++){await new Promise(r=>setTimeout(r,100));try{let x=await request('/api/session');if(x.response.ok){started=true;break}}catch{}}
  assert.ok(started,'Server failed to start');
  await assertStatus('/api/admin/state','GET',null,401);
  await assertStatus('/api/admin/start','POST',null,401);
  await assertStatus('/private/questions-bank.json','GET',null,403);
  await assertStatus('/assest/js/questions.js','GET',null,403);
  await assertStatus('/questions-for-trainers.csv','GET',null,403);
  await assertStatus('/private/questions-for-trainers.csv','GET',null,403);
  await assertStatus('/api/admin/questions.csv','GET',null,401);
  await assertStatus('/.env','GET',null,403);
  await assertStatus('/api/admin/login','POST',{password:'wrong'},401);
  const login=await assertStatus('/api/admin/login','POST',{password},200);
  cookie=login.response.headers.get('set-cookie').split(';')[0];
  await assertStatus('/api/admin/start','POST',null,409);
  const invalid=await assertStatus('/api/admin/setup','PATCH',{category:categories[0],difficultyLevels:[],quizSize:10,quizSeconds:600},400);
  await assertStatus('/api/admin/setup','PATCH',{category:categories[0],difficultyLevels:['Easy'],quizSize:51,quizSeconds:600},400);
  for(let round=0;round<categories.length;round++){
    const category=categories[round];
    const levels=variants[round];
    const setup=await assertStatus('/api/admin/setup','PATCH',{category,difficultyLevels:levels,quizSize:10,quizSeconds:600},200);
    assert.deepEqual(setup.data.round.difficultyLevels,levels);
    assert.equal(setup.data.round.category,category);
    const joined=await assertStatus('/api/participants/join','POST',{name:'Participant '+round,group:'Group 1'},201);
    const {id,token}=joined.data;
    let status=await assertStatus(`/api/participants/${id}`,'GET',null,200,token);
    assert.equal(status.data.participant.questions.length,0);
    await assertStatus(`/api/participants/${id}`,'PATCH',{index:0,answer:2},409,token);
    await assertStatus(`/api/participants/${id}`,'GET',null,403,'bad-token');
    await assertStatus('/api/admin/start','POST',null,200);
    await assertStatus('/api/participants/join','POST',{name:'Late'+round,group:'Group 2'},409);
    status=await assertStatus(`/api/participants/${id}`,'GET',null,200,token);
    let p=status.data.participant;
    assert.equal(p.questions.length,10);assert.ok(p.questions.every(q=>q.category===category));
    const breakdown=Object.fromEntries(levels.map(level=>[level,p.questions.filter(q=>q.difficulty===level).length]));
    assert.equal(Object.values(breakdown).reduce((a,b)=>a+b,0),10);
    assert.ok(Object.values(breakdown).every(v=>v>=Math.floor(10/levels.length)&&v<=Math.ceil(10/levels.length)));
    assert.ok(p.questions.every(q=> !('answerIndex' in q)&&!('explanation' in q)),'Participant received answer key!');
    if(category==='Non Verbal Intelligence Test')assert.ok(p.questions.every(q=>Array.isArray(q.visualGrid)&&q.visualGrid.length===9));
    await assertStatus(`/api/participants/${id}/submit`,'POST',null,409,token);
    for(let i=0;i<7;i++)await assertStatus(`/api/participants/${id}`,'PATCH',{index:i,answer:i%4},200,token);
    status=await assertStatus(`/api/participants/${id}`,'GET',null,200,token);
    assert.equal(status.data.participant.result,undefined);
    const sub=await assertStatus(`/api/participants/${id}/submit`,'POST',null,200,token);
    const review=await assertStatus(`/api/admin/participants/${id}/review`,'GET',null,200);
    assert.equal(review.data.review.length,10);assert.ok('answerIndex' in review.data.review[0]);
    assert.equal(sub.data.participant.submitted,true);assert.equal(sub.data.participant.result,undefined);
    await assertStatus(`/api/participants/${id}`,'PATCH',{index:8,answer:0},409,token);
    await assertStatus('/api/admin/close','POST',null,200);
    const release=await assertStatus('/api/admin/results','PATCH',{released:true},200);
    const scores=await assertStatus(`/api/participants/${id}`,'GET',null,200,token);
    assert.equal(typeof scores.data.participant.result.percentage,'number');
    const summary=await assertStatus('/api/summary','GET',null,200);
    assert.equal(summary.data.groups[0].submitted,1);
    assert.equal(typeof summary.data.groups[0].average,'number');
    await assertStatus('/api/admin/next','POST',null,200);
    const fresh=await assertStatus('/api/summary','GET',null,200);
    assert.equal(fresh.data.joined,0);
    assert.equal(fresh.data.groups[0].average,undefined);
    console.log('PASS complete flow:',category);
  }
  const csv=await assertStatus('/api/admin/questions.csv','GET',null,200);
  assert.ok(String(csv.data).includes('Mechanical Aptitude Test'));
  assert.equal(String(csv.data).split('\r\n').length-2,900);
  const results=await assertStatus('/api/admin/export.csv','GET',null,200);
  assert.ok(String(results.data).includes('Participant 0'));
  const contents=fs.readFileSync(path.join(tmp,'assessment-state.json'),'utf8');
  assert.ok(contents.includes('Participant 5')&&!contents.includes(password));
  console.log(`SUCCESS: ${passed} HTTP checks across six categories, privacy, session control, timing guards, scoring and persistence.`);
 }catch(error){console.error(error);process.exitCode=1;}finally{child.kill('SIGTERM');fs.rmSync(tmp,{recursive:true,force:true});}
}
run();
