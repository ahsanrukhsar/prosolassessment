#!/usr/bin/env python3
"""Deterministic bank builder: 6 categories x 150 questions, 50 easy / 50 medium / 50 hard.
Questions are original training examples, not standardized psychometric instruments.
"""
import json, random, csv, pathlib, math
from fractions import Fraction
R = random.Random(20261014)
ROOT = pathlib.Path(__file__).resolve().parents[1]
Q=[]
CATS=['Verbal Intelligence Test','Non Verbal Intelligence Test','Mechanical Aptitude Test','Mathematical Test','Focus Attention Test','English Vocabulary Test']

def add(cat, question, correct, wrong, explanation, difficulty, visual=None):
    assert len(wrong)>=3 and len(set(map(str,[correct]+wrong)))>=4, (cat,question,correct,wrong)
    opts=list(map(str, [correct]+wrong[:3])); R.shuffle(opts)
    idx=opts.index(str(correct))
    item={'id':f'PS-{len(Q)+1:04d}','category':cat,'difficulty':difficulty,'question':question,'options':opts,'answerIndex':idx,'explanation':str(explanation)}
    if visual is not None: item['visualGrid']=visual
    Q.append(item)

def lvl(i): return 'Medium' if i % 2 == 0 else 'Hard'

def num(x):
    if isinstance(x, Fraction):
        if x.denominator==1:return str(x.numerator)
        return f'{float(x):.2f}'
    if isinstance(x,float): return f'{x:.2f}'.rstrip('0').rstrip('.')
    return str(x)

def numeric(cat,question,answer,alt,explanation,difficulty,unit=''):
    opts=[f'{num(v)}{unit}' for v in [answer]+alt]
    if len(set(opts))<4:
        vals = []
        for v in alt+[answer+7,answer+11,answer+13,answer+17]:
            s=f'{num(v)}{unit}'
            if s!=opts[0] and s not in vals: vals.append(s)
            if len(vals)==3: break
        opts=[opts[0]]+vals
    add(cat,question,opts[0],opts[1:],explanation,difficulty)

# ENGLISH VOCABULARY: 100 curated terms with succinct definitions.
vocab_text='''
abate|become less intense|grow stronger
aberration|a deviation from what is normal|an exact repetition
acquiesce|accept without protest|oppose vigorously
alacrity|cheerful readiness|reluctant delay
ameliorate|make a situation better|make worse
anachronism|something placed in the wrong time period|a forecast
anathema|something strongly detested|a cherished ideal
apocryphal|of doubtful authenticity|fully verified
approbation|formal approval or praise|public condemnation
arduous|requiring great effort|effortless
assiduous|showing persistent care and effort|carelessly intermittent
austere|severely simple or strict|lavishly decorated
belie|give a false impression of|confirm unequivocally
bolster|support or strengthen|weaken deliberately
bombastic|using inflated language|quietly understated
capricious|subject to sudden changes of mood|consistently predictable
censure|express strong disapproval|praise warmly
circumspect|careful to consider risks|recklessly impulsive
cogent|clear and convincing|illogical and weak
conflagration|a large destructive fire|a minor drizzle
conundrum|a difficult problem or puzzle|an obvious certainty
copious|abundant in quantity|extremely scarce
corroborate|confirm with supporting evidence|contradict without evidence
deference|respectful submission to another|contemptuous disregard
delineate|describe or outline precisely|blur all boundaries
demur|raise an objection|agree immediately
deride|mock or ridicule|admire solemnly
desultory|lacking a clear plan or purpose|systematically focused
didactic|intended to teach|meant only to decorate
diffident|lacking confidence|boldly self-assured
disparate|fundamentally different|nearly identical
dissonance|a lack of harmony or agreement|complete harmony
dogmatic|asserting opinions as unquestionable|open to revision
ebullient|cheerful and full of energy|gloomily withdrawn
eclectic|drawn from a range of sources|uniformly single-sourced
efficacy|ability to produce the intended result|ineffectiveness
egregious|outstandingly bad|mildly acceptable
elucidate|make something clear|make more confusing
emulate|try to equal or surpass|refuse to imitate
enervate|drain of energy or vitality|invigorate
engender|cause or give rise to|prevent entirely
ephemeral|lasting for a very short time|permanent
equanimity|calmness under pressure|panicked agitation
equivocal|open to more than one interpretation|unambiguously clear
erudite|having extensive knowledge|poorly informed
esoteric|understood by a small specialist group|universally familiar
exacerbate|make a problem more severe|alleviate
exculpate|clear from blame|declare guilty
exigent|urgent and demanding immediate action|unimportant and deferrable
expedient|convenient despite possible moral compromise|principled despite inconvenience
fastidious|very attentive to detail|sloppy and careless
fortuitous|happening by chance, often beneficially|carefully planned
fractious|irritable and difficult to control|calm and compliant
garrulous|excessively talkative|brief and reserved
germane|directly relevant|unrelated
hackneyed|overused and unoriginal|fresh and inventive
imminent|about to happen|unlikely for years
immutable|unable to be changed|easily altered
impetuous|acting without thought|deliberately cautious
inchoate|only partly formed or developed|fully mature
incongruous|out of place or inconsistent|harmoniously fitting
indefatigable|persisting without tiring|quickly exhausted
inexorable|impossible to stop or prevent|readily reversible
inimical|hostile or harmful|friendly and beneficial
insidious|gradually harmful in a subtle way|openly harmless
intrepid|fearlessly adventurous|timid
laconic|using very few words|excessively wordy
latent|present but not yet apparent|fully visible
laudable|worthy of praise|deserving criticism
loquacious|inclined to talk a great deal|habitually silent
lucid|clear and easy to understand|obscure and muddled
magnanimous|generous toward a rival|petty and vindictive
mitigate|make less severe|intensify
nebulous|vague or ill-defined|precisely outlined
obdurate|stubbornly refusing to change|easily persuaded
obfuscate|make deliberately unclear|clarify
obsequious|excessively eager to please|independently forthright
ostensible|stated or apparent but not necessarily true|proven actual
paradigm|a typical model or framework|an isolated exception
parsimonious|unwilling to spend or use resources|extravagantly generous
perfunctory|done with little care or interest|done conscientiously
pernicious|having a very harmful effect|completely benign
perspicacious|quick to understand and judge accurately|slow to grasp matters
placate|make someone less angry|provoke further
pragmatic|guided by practical considerations|purely theoretical
precipitous|very steep or sudden|gradual and gentle
proclivity|a natural tendency or inclination|an acquired aversion
prodigious|remarkably great in extent or degree|very small
prosaic|ordinary and lacking imagination|exceptionally poetic
quixotic|idealistic in an impractical way|realistically grounded
recalcitrant|resisting authority or control|cooperative
redolent|strongly suggestive or fragrant of|devoid of association
reproach|express disappointment or disapproval|commend highly
rescind|officially revoke or cancel|formally enact
sagacious|wise and discerning|foolish
salient|most noticeable or important|peripheral and irrelevant
scrupulous|careful to act honestly and thoroughly|careless about principles
soporific|tending to induce sleep|stimulating alertness
spurious|false or lacking authenticity|genuinely valid
superfluous|more than is needed|absolutely essential
surreptitious|done secretly to avoid notice|open and public
taciturn|habitually reserved in speech|constantly talkative
tenacious|persistent in holding on|easily discouraged
tenuous|weak or insubstantial|strongly supported
transient|lasting only briefly|permanent
ubiquitous|present almost everywhere|rarely encountered
unwieldy|difficult to carry or manage|easy to handle
vacillate|waver between alternatives|decide firmly
venerate|regard with deep respect|treat with contempt
verbose|using more words than needed|concise
vindicate|clear from accusation by evidence|prove guilty
vitriolic|bitterly harsh in criticism|warmly conciliatory
zealous|showing intense enthusiasm|indifferent
'''
vocab=[x.strip().split('|') for x in vocab_text.strip().splitlines()]
# 110+ curated words. Deterministically select 100. Alternating meaning and reverse meaning.
assert len(vocab)>=100,len(vocab)
for i,(word,meaning,opposite) in enumerate(vocab[:100]):
    distractor_pool=[v[1] for v in vocab if v[0]!=word and v[1]!=meaning]
    # Ensure semantically distinct terms, instead of the antonym being an obvious giveaway.
    start=(i*11)%len(distractor_pool); ds=[distractor_pool[(start+j*19)%len(distractor_pool)] for j in range(3)]
    if len(set(ds))<3: ds=R.sample(distractor_pool,3)
    if i%2==0:
        q=f'Which definition most accurately matches “{word}”?'
    else:
        q=f'Choose the precise meaning of the word “{word}” in formal English.'
    add(CATS[5],q,meaning,ds,f'“{word}” means {meaning}. Its opposite sense is: {opposite}.',lvl(i))

# VERBAL INTELLIGENCE: relational, logical & critical reasoning distinct from vocabulary drills.
analogies='''
thermometer:temperature|barometer:pressure|compass:metal|telescope:gravity|ruler:time
architect:blueprint|composer:score|chef:oven|pilot:airport|driver:map
hypothesis:experiment|claim:evidence|conclusion:question|theory:opinion|rumour:repetition
seed:germination|egg:hatching|soil:harvesting|leaf:evaporation|branch:pollination
judge:verdict|referee:decision|witness:suspect|lawyer:evidence|jury:trial
antidote:poison|remedy:ailment|medicine:doctor|fire:smoke|water:thirst
prologue:novel|overture:opera|chapter:author|index:library|epilogue:poet
cartographer:map|lexicographer:dictionary|biologist:microscope|editor:camera|astronomer:compass
ore:metal|crude oil:petroleum product|sand:glass bottle|paper:tree|wheat:field
axiom:proof|premise:argument|answer:question|objection:agreement|observation:instrument
catalyst:reaction|enzyme:digestion|thermostat:alarm|battery:wire|brake:vehicle
archive:records|reservoir:water|orchard:workers|harbour:ships|warehouse:drivers
skeptic:doubt|optimist:hope|cynic:agreement|mentor:resentment|critic:celebration
elasticity:deformation|viscosity:flow resistance|density:distance|gravity:light|voltage:temperature
hindsight:past|foresight:future|memory:present|guessing:history|prediction:yesterday
filtration:particles|distillation:boiling points|sieving:light|freezing:pressure|condensation:weight
paleontology:fossils|numismatics:coins|botany:chemicals|geology:stars|astronomy:rocks
legislature:statutes|court:judgments|hospital:teachers|museum:patients|library:athletes
iris:light|diaphragm:aperture|hinge:sound|wheel:temperature|valve:weight
metaphor:comparison|hyperbole:exaggeration|alliteration:proof|pun:arithmetic|irony:sequence
rehearsal:performance|prototype:production|audit:accounting|invoice:proposal|exam:attendance
precursor:successor|cause:effect|premise:refutation|sign:absence|question:retrospect
linguist:language|entomologist:insects|geographer:microscopes|chemist:weather|economist:fossils
opacity:light transmission|insulation:heat transfer|capacity:weight ratio|thickness:speed|volume:noise
needle:compass|pendulum:clock|antenna:printing|lens:typing|brake:compass
'''
for i,line in enumerate(analogies.strip().splitlines()):
    a,b,c,d,e=line.split('|'); a1,a2=a.split(':'); b1,b2=b.split(':')
    add(CATS[0],f'Complete the analogy: {a1.title()} is to {a2} as {b1.title()} is to _____.',b2,[c.split(':')[-1],d.split(':')[-1],e.split(':')[-1]],f'The relationship between {a1} and {a2} is analogous to that between {b1} and {b2}.',lvl(i))
# Deduction sets: all A are B, all B are C -> all A are C. Names vary; answers vary.
entities=[('auditors','analysts','employees'),('sparrows','birds','animals'),('bronze medals','awards','objects'),('curators','professionals','workers'),('sapphires','gems','minerals'),('orchids','plants','organisms'),('novels','books','publications'),('managers','staff members','people'),('rectangles','quadrilaterals','polygons'),('laptops','computers','devices'),('surgeons','doctors','professionals'),('trams','vehicles','machines'),('violas','instruments','objects'),('satellites','spacecraft','objects'),('tulips','flowers','plants'),('editors','reviewers','workers'),('ravens','birds','animals'),('oak trees','trees','plants'),('sculptures','artworks','objects'),('refrigerators','appliances','devices'),('cryptographers','specialists','people'),('currencies','financial units','quantities'),('dictionaries','reference works','publications'),('prisms','solids','geometric objects'),('beagles','dogs','mammals')]
for i,(a,b,c) in enumerate(entities):
    if i%2==0:
        q=f'All {a} are {b}. All {b} are {c}. Which conclusion must follow?'
        correct=f'All {a} are {c}.'
        wrong=[f'All {c} are {a}.',f'No {a} are {c}.',f'Some {c} are not {b}.']
        explain='Universal set inclusion is transitive: A ⊆ B and B ⊆ C imply A ⊆ C.'
    else:
        q=f'No {a} are {b}. All {c} are {a}. Which conclusion must follow?'
        correct=f'No {c} are {b}.'
        wrong=[f'All {b} are {c}.',f'Some {c} are {b}.',f'No {a} are {c}.']
        explain='Since C is contained in A and A has no overlap with B, C has no overlap with B.'
    add(CATS[0],q,correct,wrong,explain,lvl(i+25))
# Ordering logic: exactly 4 candidates constrained. Solve with permutations to prevent ambiguity.
import itertools
names=['Arif','Bina','Cyrus','Dina','Eman','Faraz','Gita','Haris','Iqra','Jamal','Kiran','Laila','Mina','Noman','Omer','Pari','Qasim','Rida','Sana','Tariq','Umair','Vera','Waqas','Yara','Zoya','Azim','Bushra','Danial','Fariha','Hina']
for i in range(25):
    p=names[i:i+4]
    if len(p)<4: p=names[0:4]
    # A before B, B before C, D last; unique full order => A B C D.
    a,b,c,d=p
    if i%2==0:
        q=f'Four presentations are scheduled. {a} speaks before {b}; {b} speaks before {c}; and {d} speaks last. Who must speak second?'
        ans=b; explain=f'The only possible order is {a}, {b}, {c}, {d}.'
    else:
        q=f'Four files are reviewed. {a} is reviewed before {b}; {b} before {c}; {d} is last. Which file is reviewed immediately before {d}?'
        ans=c; explain=f'The only possible review order is {a}, {b}, {c}, {d}.'
    add(CATS[0],q,ans,[x for x in p if x!=ans],explain,lvl(i+50))
# Conditional inference, with distinct propositions per item.
cond=[('a contract is signed','the project is authorized'),('the alarm is armed','the indicator turns green'),('a bid is accepted','procurement issues an order'),('the thermostat reaches its set point','the heater switches off'),('the customer verifies identity','the account is activated'),('the file passes validation','the record is imported'),('the door sensor is triggered','the alert is logged'),('the shipment clears customs','a release notice is issued'),('the invoice is approved','payment is scheduled'),('the sensor detects smoke','an alarm is sounded'),('the budget is ratified','the plan can proceed'),('the device passes calibration','a certificate is issued'),('the audit finds a discrepancy','a review is opened'),('a claim is substantiated','the appeal is accepted'),('the bridge is closed','a diversion is announced'),('the database reaches capacity','an alert is raised'),('the badge is scanned','an entry is recorded'),('the manager approves the request','a ticket is created'),('the flight departs','the departure is logged'),('a patch passes tests','the release is permitted'),('the password expires','the account requests renewal'),('the deposit is confirmed','the reservation becomes valid'),('the water level rises','the overflow sensor activates'),('a sample is contaminated','the batch is quarantined'),('the lecture is postponed','students receive a notice')]
for i,(p,q) in enumerate(cond):
    if i%2==0:
        premise=f'If {p}, then {q}. We know that {p}.'
        correct=f'It follows that {q}.'
        wrong=[f'It follows that {q} is false.',f'It follows that {p} is false.',f'No conclusion about {q} is possible.']
        exp='Modus ponens: P → Q and P together imply Q.'
    else:
        premise=f'If {p}, then {q}. We know that it is false that {q}.'
        correct=f'It follows that it is false that {p}.'
        wrong=[f'It follows that {p}.',f'It follows that {q}.',f'No conclusion about {p} is possible.']
        exp='Modus tollens: P → Q and not-Q together imply not-P.'
    add(CATS[0],f'{premise} Which inference is logically valid?',correct,wrong,exp,lvl(i+75))
assert sum(x['category']==CATS[0] for x in Q)==100

# NON VERBAL intelligence: 100 real symbol-matrix puzzles with 3x3 stimulus grids.
# visualGrid is rendered as a diagram, not a prose-only analogy.
arrows=['↑','↗','→','↘','↓','↙','←','↖']
shapes=['▲','●','■','◆','★','⬟','⬢','✚']
for i in range(100):
    family=i//20; seed=i%20
    if family==0: # arrow turns: step per column and per row
        start=(seed*3)%8; a=1+(seed%3); b=2+(seed%3)
        grid=[arrows[(start+r*b+c*a)%8] for r in range(3) for c in range(3)]
        vals=arrows; explanation=f'Across each row the direction rotates {a*45}° clockwise; down rows it rotates {b*45}°.'
    elif family==1: # cyclic sequence of shape classes
        start=(seed*3)%8; a=1+(seed%3); b=1+((seed//3)%3)
        grid=[shapes[(start+r*b+c*a)%8] for r in range(3) for c in range(3)]
        vals=shapes; explanation='The symbol indices advance by a fixed step across columns and by another fixed step across rows.'
    elif family==2: # count arithmetic within 1..5 dots
        start=seed%5; a=(seed%2)+1; b=(seed//2)%3+1
        dot=lambda n:'●'*n
        grid=[dot(((start+r*b+c*a)%5)+1) for r in range(3) for c in range(3)]
        vals=[dot(k) for k in range(1,6)]; explanation=f'Dot count increases cyclically by {a} between columns and {b} between rows (wrap after 5).'
    elif family==3: # cyclic alternating filled / unfilled / symbol shapes
        base=['▲','△','■','□','●','○','◆','◇']
        start=(seed*5)%8; a=1+(seed%3); b=2+(seed%2)
        grid=[base[(start+r*b+c*a)%8] for r in range(3) for c in range(3)]
        vals=base; explanation='Trace the repeating filled/outline shape cycle with constant horizontal and vertical steps.'
    else: # combinations of arrow + dot count
        start=(seed*3)%4; step=(seed%3)+1; b=1+(seed//3)%3
        arr=['↑','→','↓','←']; combo=[f'{x}{k}' for x in arr for k in ['•','••']]
        grid=[f'{arr[(start+c*step+r*b)%4]}{"•"*(1+((seed+c+r)%2))}' for r in range(3) for c in range(3)]
        vals=combo; explanation='Direction follows a rotation rule across rows and columns, while dot count alternates according to cell position.'
    answer=grid[8]; options=[x for x in vals if x!=answer]
    R.shuffle(options)
    grid[8]='?'
    add(CATS[1],f'Visual reasoning matrix {i+1}: select the symbol that completes the 3 × 3 pattern.',answer,options[:3],explanation,lvl(i),grid)

# MECHANICAL: 10 distinct physics / engineering constructs x 10 parameters.
for i in range(100):
    kind=i//10; n=i%10; d=lvl(i)
    if kind==0:
        z1=12+2*n; z2=36+4*n; rpm=120+20*n; ans=Fraction(z1*rpm,z2)
        numeric(CATS[2],f'An ideal gear with {z1} teeth rotates at {rpm} rpm and drives a {z2}-tooth gear. What is the driven speed?',ans,[Fraction(z2*rpm,z1),Fraction(rpm),Fraction(ans,1)*2],f'Conservation of tooth engagement: driven rpm = {rpm} × {z1}/{z2} = {num(ans)} rpm.',d,' rpm')
    elif kind==1:
        arm1=2+n; arm2=4+2*n; load=80+20*n; ans=Fraction(load*arm2,arm1)
        numeric(CATS[2],f'An ideal lever has an effort arm of {arm1} m and a load arm of {arm2} m. What effort balances a {load} N load?',ans,[Fraction(load*arm1,arm2),load,load+30],f'Balance torques: effort × {arm1} = {load} × {arm2}.',d,' N')
    elif kind==2:
        a=2+n; b=4*a; inputforce=25+10*n; ans=inputforce*b//a
        numeric(CATS[2],f'A hydraulic press has input piston area {a} cm² and output area {b} cm². Input force is {inputforce} N. Assuming no losses, find output force.',ans,[inputforce,ans//2,ans*2],f'Pascal’s principle: output force = input force × area ratio = {inputforce} × {b}/{a}.',d,' N')
    elif kind==3:
        res=6+2*n; volt=12+3*n; amp=Fraction(volt,res)
        numeric(CATS[2],f'A resistor of {res} Ω is connected to an ideal {volt} V supply. What current flows?',amp,[Fraction(res,volt),amp*2,amp+2],f'Ohm’s law I = V/R = {volt}/{res} A.',d,' A')
    elif kind==4:
        mass=5+2*n; height=3+n; work=mass*10*height
        numeric(CATS[2],f'With g = 10 m/s², what minimum work is needed to lift a {mass} kg load vertically by {height} m (ignore losses)?',work,[mass*height,work//2,work*2],f'Gravitational work W = mgh = {mass} × 10 × {height} J.',d,' J')
    elif kind==5:
        k=100+20*n; x=0.05+0.01*n; force=k*x
        numeric(CATS[2],f'A linear spring has stiffness {k} N/m. How much force is required to extend it by {x:.2f} m?',force,[force*2,force/2,force+10],f'Hooke’s law F = kx = {k} × {x:.2f} N.',d,' N')
    elif kind==6:
        wheel=2+n; load=100+25*n; pull=Fraction(load,wheel)
        numeric(CATS[2],f'An ideal pulley arrangement has {wheel} rope segments supporting a {load} N load. Find the minimum applied pulling force.',pull,[load,load*wheel,pull+25],f'Ideal mechanical advantage equals {wheel}; effort = {load}/{wheel} N.',d,' N')
    elif kind==7:
        density=1000; depth=2+n; ans=density*10*depth
        numeric(CATS[2],f'What is the gauge pressure at depth {depth} m in still water (density 1,000 kg/m³, g = 10 m/s²)?',ans,[ans//10,ans*2,ans+1000],f'Hydrostatic gauge pressure p = ρgh = 1,000 × 10 × {depth} Pa.',d,' Pa')
    elif kind==8:
        mass=8+2*n; accel=2+n; force=mass*accel
        numeric(CATS[2],f'A {mass} kg trolley accelerates at {accel} m/s² on a frictionless horizontal track. What net force is required?',force,[mass+accel,force*2,force+mass],f'Newton’s second law F = ma = {mass} × {accel} N.',d,' N')
    else:
        length=3+n; rise=1+(n%3); load=120+20*n; required=Fraction(load*rise,length)
        numeric(CATS[2],f'A frictionless ramp of length {length} m raises a load by {rise} m. What ideal force parallel to the ramp lifts a {load} N load steadily?',required,[load,Fraction(load*length,rise),required+load],f'Work balance: F × length = load × rise; F = {load} × {rise}/{length} N.',d,' N')

# MATHEMATICAL: 10 families x 10 carefully soluble numerical word problems.
for i in range(100):
    kind=i//10;n=i%10;d=lvl(i)
    if kind==0:
        x=3+n; a=2+n; b=5+2*n; rhs=a*x+b
        numeric(CATS[3],f'Solve for x: {a}x + {b} = {rhs}.',x,[x+1,x-1,x+2],f'Subtract {b}, then divide by {a}.',d)
    elif kind==1:
        price=200+50*n; disc=10+5*(n%4); ans=Fraction(price*(100-disc),100)
        numeric(CATS[3],f'An item costs Rs {price}. It receives a {disc}% discount. What is the final price before tax?',ans,[price,price+ans,price*disc/100],f'Multiply list price by (1 − {disc}/100).',d,' Rs')
    elif kind==2:
        a=2+n; b=3+n; c=4+n; ans=Fraction(1,Fraction(1,a)+Fraction(1,b)+Fraction(1,c))
        numeric(CATS[3],f'Three machines independently complete a task in {a}, {b}, and {c} hours. If they work together at constant rates, how many hours are required?',ans,[Fraction(a+b+c,3),Fraction(a*b,a+b),a+b+c],f'Combined hourly rate = 1/{a} + 1/{b} + 1/{c}; invert the rate.',d,' h')
    elif kind==3:
        red=3+n; blue=5+n; total=red+blue; ans=Fraction(red,total)
        numeric(CATS[3],f'A bag contains {red} red and {blue} blue balls. One ball is drawn randomly. What is P(red)?',ans,[Fraction(blue,total),Fraction(red,blue),Fraction(1,red)],f'Probability = red / total = {red}/{total}.',d)
    elif kind==4:
        a=3+n;diff=2+n; k=6+n;ans=a+(k-1)*diff
        numeric(CATS[3],f'An arithmetic sequence begins {a}, {a+diff}, {a+2*diff}, ... . What is its {k}th term?',ans,[a+k*diff,ans-diff,ans+2*diff],f'nth term = first + (n−1) × common difference.',d)
    elif kind==5:
        x=10+2*n;y=7+n;total=3*x+2*y
        numeric(CATS[3],f'Three identical notebooks and two identical pens cost Rs {total}. Each pen costs Rs {y}. How much does one notebook cost?',x,[y,3*x,total-2*y],f'3N + 2×{y} = {total}; N = ({total}−{2*y})/3.',d,' Rs')
    elif kind==6:
        w=6+n; h=4+2*n; diag=w*w+h*h
        numeric(CATS[3],f'A rectangle is {w} cm by {h} cm. What is its area?',w*h,[2*(w+h),w+h,diag],f'Area = length × width = {w} × {h} cm².',d,' cm²')
    elif kind==7:
        first=20+n; second=25+2*n; dist=(first+second)*3
        numeric(CATS[3],f'Two vehicles travel towards each other at {first} km/h and {second} km/h. They start {dist} km apart. How many hours until they meet?',3,[dist/first,dist/second,6],f'Closing speed = {first}+{second} km/h; time = {dist}/({first}+{second}) = 3 h.',d,' h')
    elif kind==8:
        base=7+n; mod=5+n; exp=3+n; ans=pow(base,exp,mod)
        numeric(CATS[3],f'Find the remainder when {base}^{exp} is divided by {mod}.',ans,[(ans+1)%mod,(ans+2)%mod,(ans+3)%mod],f'Use modular exponentiation: {base}^{exp} mod {mod} = {ans}.',d)
    else:
        start=600+100*n; r=10+2*(n%5); end=start*(1+r/100)**2; answer=end-start
        numeric(CATS[3],f'Rs {start} is invested at {r}% annual compound interest for 2 years. How much interest is earned (nearest paisa)?',round(answer,2),[round(start*r/100*2,2),round(start*r/100,2),round(answer+start,2)],f'Compound interest = P[(1+r/100)^2−1] = Rs {answer:.2f}.',d,' Rs')

# FOCUS ATTENTION: detailed inspection tasks, exact matching, counting, transposition, ordering.
letters='ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
def token(n=12): return ''.join(R.choice(letters) for _ in range(n))
def mutate(s, pos=None):
    pos=R.randrange(len(s)) if pos is None else pos
    new=R.choice([x for x in letters if x!=s[pos]])
    return s[:pos]+new+s[pos+1:]
for i in range(100):
    kind=i//10;n=i%10;d=lvl(i)
    if kind==0:
        target=token(14+n%5); variants=[mutate(target,1),mutate(target,len(target)-2),mutate(target,len(target)//2)]
        add(CATS[4],f'Which code EXACTLY matches the reference? Reference: {target}',target,variants,'Only the exact character-by-character match is correct.',d)
    elif kind==1:
        s=token(15+n%6); char=s[n%len(s)]; cnt=s.count(char)
        # Guarantee 4 distinct counts; range 0..n
        add(CATS[4],f'Count every occurrence of “{char}” (case-sensitive) in: {s}',str(cnt),[str(cnt+1),str(cnt+2),str(max(0,cnt-1)) if cnt>0 else str(cnt+3)],f'Character “{char}” occurs {cnt} time(s).',d)
    elif kind==2:
        base=token(16); pos=2+n; variant=mutate(base,pos)
        add(CATS[4],f'The two strings differ in exactly one position. Which position (counting from 1) is different? A: {base} | B: {variant}',str(pos+1),[str(pos),str(pos+2),str(pos+3)],f'The mismatch is at character position {pos+1}.',d)
    elif kind==3:
        s=token(9+n%4); rev=s[::-1]; wrong=[mutate(rev,0),mutate(rev,len(rev)//2),mutate(rev,-2)]
        add(CATS[4],f'Which option is the EXACT reverse of this string? {s}',rev,wrong,f'Reading backwards gives {rev}.',d)
    elif kind==4:
        s=token(13+n%4); idx=2+n; t=s[:idx]+s[idx+1:]; missing=s[idx]
        add(CATS[4],f'One character is missing from the shorter code. Identify it. Original: {s} | Shorter: {t}',missing,R.sample([x for x in letters if x!=missing],3),f'The removed character is {missing} at original position {idx+1}.',d)
    elif kind==5:
        s=token(12); idx=2+n%8
        while s[idx]==s[idx+1]: s=token(12)
        a=list(s); a[idx],a[idx+1]=a[idx+1],a[idx]
        target=''.join(a)
        add(CATS[4],f'Which code results from swapping positions {idx+1} and {idx+2} in {s}?',target,[mutate(target,0),mutate(target,-1),s],f'Only those two positions are interchanged.',d)
    elif kind==6:
        s=token(12+n%5); letters_only=[x for x in s if x.isalpha()]; c=len(letters_only)
        add(CATS[4],f'How many LETTERS (not digits) occur in the following mixed code? {s}',str(c),[str(c+1),str(c-1),str(c+2)],f'There are {c} alphabetic characters, excluding numerals.',d)
    elif kind==7:
        s=token(12); k=2+n%4; chunks=[s[j:j+k] for j in range(0,len(s),k)]; correct='-'.join(chunks)
        add(CATS[4],f'Starting at the left, insert a hyphen after every {k} characters (no trailing hyphen): {s}',correct,[mutate(correct,0),'-'.join(chunks[::-1]),mutate(correct,-1)],f'Split the code into consecutive blocks of {k}: {correct}.',d)
    elif kind==8:
        s=token(15); index=3+n%9; sym=s[index]; t=s[:index]+sym+s[index:]
        add(CATS[4],f'An extra character was inserted in string B. What character was duplicated? A: {s} | B: {t}',sym,R.sample([x for x in letters if x!=sym],3),f'The inserted duplicate is {sym}.',d)
    else:
        s=token(12); target=s[1::2]; variants=[mutate(target,0),mutate(target,2),mutate(target,-1)]
        add(CATS[4],f'Read the characters at EVEN positions (2, 4, 6, ...) only. Which extracted string is correct? {s}',target,variants,f'The characters at one-based positions 2,4,6,... form {target}.',d)

from add_easy import append_easy
append_easy(add, numeric, R, CATS)
assert len(Q)==900, (len(Q),{c:sum(x['category']==c for x in Q) for c in CATS})
assert all(sum(x['category']==c for x in Q)==150 for c in CATS)
assert all(sum(x['category']==c and x['difficulty']==d for x in Q)==50 for c in CATS for d in ['Easy','Medium','Hard'])
assert len(set(x['id'] for x in Q))==900
assert all(len(x['options'])==4 and len(set(x['options']))==4 and 0<=x['answerIndex']<4 for x in Q)
assert len(set((x['category'],x['question'],tuple(x.get('visualGrid',[]))) for x in Q))==900
(ROOT/'private'/'questions-bank.json').write_text(json.dumps(Q,ensure_ascii=False,indent=2),encoding='utf8')
with (ROOT/'private'/'questions-for-trainers.csv').open('w',newline='',encoding='utf-8-sig') as f:
    writer=csv.writer(f)
    writer.writerow(['ID','Category','Difficulty','Question','Visual grid row 1','Visual grid row 2','Visual grid row 3','A','B','C','D','Correct','Explanation'])
    for x in Q:
        v=x.get('visualGrid',[])
        writer.writerow([x['id'],x['category'],x['difficulty'],x['question'],*([' '.join(v[a:a+3]) for a in (0,3,6)] if v else ['','','']),*x['options'],'ABCD'[x['answerIndex']],x['explanation']])
print('Built 900 questions; category counts:',{c:sum(x['category']==c for x in Q) for c in CATS})
