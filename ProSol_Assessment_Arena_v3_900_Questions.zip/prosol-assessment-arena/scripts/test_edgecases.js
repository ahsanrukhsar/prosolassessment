'use strict';
const {spawn}=require('node:child_process');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const crypto=require('node:crypto');
const assert=require('node:assert/strict');
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'ps-edge-'));
const password='Edge-Test-Password-2026!';
const stateFile=path.join(dir,'state.json');
let port=18000+crypto.randomInt(8000);let url=`http://127.0.0.1:${port}`;
const root=path.resolve(__dirname,'..');
let child=null,cookie='';
const sleep=t=>new Promise(r=>setTimeout(r,t));
async function boot(file=stateFile){
  port+=1;url=`http://127.0.0.1:${port}`;
  child=spawn(process.execPath,['server.js'],{cwd:root,env:{...process.env,ADMIN_PASSWORD:password,PORT:String(port),NODE_ENV:'development',ASSESSMENT_DATA_FILE:file,DATABASE_URL:''},stdio:['ignore','pipe','pipe']});
  let output='';child.stdout.on('data',d=>output+=d);
  for(let i=0;i<70;i++){await sleep(75);try{const r=await fetch(url+'/api/health');if(r.ok)return;}catch{}}
  throw Error('Unable to boot server: '+output+' exit='+child.exitCode+' port='+port);
}
async function stop(){if(child){const old=child;await new Promise(resolve=>{if(old.exitCode!==null)return resolve();old.once('exit',resolve);old.kill('SIGTERM');setTimeout(resolve,1200);});child=null;}}
async function req(p,method='GET',data,token){
  const r=await fetch(url+p,{method,headers:{...(data?{'Content-Type':'application/json'}:{}),...(cookie?{Cookie:cookie}:{}),...(token?{'X-Participant-Token':token}:{})},...(data?{body:JSON.stringify(data)}:{})});
  const v=await r.json().catch(()=>null);return {status:r.status,v,headers:r.headers};
}
async function status(p,method,data,expected,token){const r=await req(p,method,data,token);assert.equal(r.status,expected,`${p}: ${JSON.stringify(r.v)}`);return r;}
async function login(){const r=await status('/api/admin/login','POST',{password},200);cookie=r.headers.get('set-cookie').split(';')[0];}
async function run(){
 try{
  // Automatic deadline closure does not need a manual Close button.
  const token='expired-participant-token';const id=crypto.randomUUID();const hash=crypto.createHash('sha256').update(token).digest('hex');
  const expired={round:{id:'deadline-test',phase:'live',category:'Mathematical Test',difficultyLevels:['Easy'],quizSize:1,quizSeconds:60,createdAt:'2026-01-01T00:00:00.000Z',startsAt:'2026-01-01T00:00:00.000Z',endsAt:'2026-01-01T00:01:00.000Z',resultsReleased:false},participants:{[id]:{id,name:'Past Participant',group:'Group 1',roundId:'deadline-test',tokenHash:hash,category:'Mathematical Test',startedAt:'2026-01-01T00:00:00.000Z',endsAt:'2026-01-01T00:01:00.000Z',answers:{0:1},questionIds:['PS-0301'],submittedAt:null}}};
  fs.writeFileSync(stateFile,JSON.stringify(expired));await boot();await login(); console.log('STAGE expired test');
  const current=await status('/api/session','GET',undefined,200);assert.equal(current.v.phase,'closed');
  await status('/api/admin/results','PATCH',{released:true},200);
  const result=await status(`/api/participants/${id}`,'GET',undefined,200,token);assert.ok(result.v.participant.result);
  await status('/api/admin/next','POST',undefined,200);await stop();
  // Concurrent submissions are serialized and survive a restart.
  fs.rmSync(stateFile,{force:true});cookie='';await boot();await login();console.log('STAGE concurrent starts');
  await status('/api/admin/setup','PATCH',{category:'Focus Attention Test',difficultyLevels:['Easy','Medium','Hard'],quizSize:12,quizSeconds:600},200);
  const members=await Promise.all(Array.from({length:24},(_,i)=>status('/api/participants/join','POST',{name:'Simultaneous '+i,group:'Group '+(1+i%5)},201)));
  await status('/api/admin/start','POST',undefined,200);
  const tasks=[];
  for(const {v} of members)for(let n=0;n<9;n++)tasks.push(status(`/api/participants/${v.id}`,'PATCH',{index:n,answer:n%4},200,v.token));
  await Promise.all(tasks);console.log('STAGE concurrent answers saved');
  for(const {v} of members){const p=await status(`/api/participants/${v.id}`,'GET',undefined,200,v.token);assert.equal(Object.keys(p.v.participant.answers).length,9);}
  await stop();cookie='';await boot();await login();console.log('STAGE restart verify');
  let summary=await status('/api/admin/state','GET',undefined,200);assert.equal(summary.v.participants.length,24);assert.ok(summary.v.participants.every(p=>p.answered===9));
  await stop();
  // A file-write failure must not make unsaved registration appear successful.
  cookie='';await boot('/sys/prosol-results-no-write/state.json');await login();console.log('STAGE write failure');
  const rejected=await status('/api/participants/join','POST',{name:'Must Not Persist',group:'Group 1'},500);
  const after=await status('/api/summary','GET',undefined,200);assert.equal(after.v.joined,0);
  console.log('EDGE TESTS PASS: automatic expiry, release after deadline, 216 concurrent answers, restart persistence, failed-write rollback.');
 }finally{await stop();fs.rmSync(dir,{recursive:true,force:true});}
}
run().catch(err=>{console.error(err);process.exitCode=1;});
