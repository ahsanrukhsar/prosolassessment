'use strict';
// Mock-Postgres smoke test; verifies the adapter interface, not a live Neon connection.
const {spawn}=require('node:child_process'),fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..');const temp=fs.mkdtempSync(path.join(os.tmpdir(),'pspg-'));const modules=path.join(temp,'node_modules','pg');fs.mkdirSync(modules,{recursive:true});
fs.writeFileSync(path.join(modules,'index.js'),String.raw`
const fs=require('fs');
class Pool {
 async query(sql,args=[]) {
  const f=process.env.PROTEST_PG_FILE;
  if(sql.startsWith('CREATE TABLE'))return {rowCount:0};
  if(sql.startsWith('INSERT INTO')) {if(!fs.existsSync(f))fs.writeFileSync(f,args[0]);return {rowCount:1};}
  if(sql.startsWith('SELECT payload'))return {rows:[{payload:JSON.parse(fs.readFileSync(f,'utf8'))}]};
  if(sql.startsWith('UPDATE prosol_app_state')){fs.writeFileSync(f,args[0]);return {rowCount:1};}
  throw Error('Unrecognized query '+sql);
 }
 async end(){}
}
module.exports={Pool};
`);
const port=18000+crypto.randomInt(10000), base=`http://127.0.0.1:${port}`, password='Postgres-Test-Only-2026!';let child=null;
async function start(){
 child=spawn(process.execPath,['server.js'],{cwd:root,env:{...process.env,PORT:String(port),NODE_ENV:'production',ADMIN_PASSWORD:password,DATABASE_URL:'postgresql://mock/db?sslmode=require',NODE_PATH:path.join(temp,'node_modules'),PROTEST_PG_FILE:path.join(temp,'row.json')},stdio:'ignore'});
 for(let i=0;i<70;i++){await new Promise(r=>setTimeout(r,75));try{let r=await fetch(base+'/api/health');if(r.ok){assert.equal((await r.json()).storage,'postgres');return;}}catch{}}
 throw Error('PostgreSQL mock-mode server did not start.');
}
async function stop(){if(child){const old=child;await new Promise(r=>{old.once('exit',r);old.kill();setTimeout(r,900)});child=null;}}
async function run(){try{
 await start();const login=await fetch(base+'/api/admin/login',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({password})});assert.equal(login.status,200);const cookie=login.headers.get('set-cookie').split(';')[0];
 const join=await fetch(base+'/api/participants/join',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({name:'Persistence Test',group:'Group 1'})});assert.equal(join.status,201);
 await stop();await start();
 const admin=await fetch(base+'/api/admin/login',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({password})});const freshCookie=admin.headers.get('set-cookie').split(';')[0];
 const resp=await fetch(base+'/api/admin/state',{headers:{Cookie:freshCookie}});assert.equal(resp.status,200);const v=await resp.json();assert.equal(v.participants.length,1);
 console.log('Postgres adapter mock PASS: production startup, PostgreSQL read/write, restart persistence. No live provider credentials tested.');
 }finally{await stop();fs.rmSync(temp,{recursive:true,force:true});}}
run().catch(e=>{console.error(e);process.exitCode=1;});
