'use strict';
// Safely import an existing v2/v3 JSON state into an EMPTY managed Postgres database.
// Run while no assessment server is using this destination database.
const fs=require('node:fs');
const path=require('node:path');
const pg=require('pg');
(async()=>{
  const source=process.argv[2];
  if(!source||!process.env.DATABASE_URL){console.error('Usage: DATABASE_URL="postgresql://..." node scripts/migrate_json_to_postgres.js path/to/assessment-state.json');process.exitCode=2;return;}
  const state=JSON.parse(fs.readFileSync(path.resolve(source),'utf8'));
  if(!state.round?.id||!state.participants||typeof state.participants!=='object')throw Error('Invalid assessment-state.json.');
  const pool=new pg.Pool({connectionString:process.env.DATABASE_URL,max:1,connectionTimeoutMillis:30000});
  try{
    await pool.query(`CREATE TABLE IF NOT EXISTS prosol_app_state(id INTEGER PRIMARY KEY CHECK(id=1), payload JSONB NOT NULL, modified_at TIMESTAMPTZ NOT NULL DEFAULT NOW())`);
    const rows=await pool.query('SELECT payload FROM prosol_app_state WHERE id=1');
    if(rows.rows.length){
      const existing=rows.rows[0].payload;
      if(Object.keys(existing.participants||{}).length || existing.round?.startsAt)throw Error('Destination database contains active or historical results. Import aborted to protect data.');
      await pool.query('UPDATE prosol_app_state SET payload=$1::jsonb,modified_at=NOW() WHERE id=1',[JSON.stringify(state)]);
    }else await pool.query('INSERT INTO prosol_app_state(id,payload) VALUES(1,$1::jsonb)',[JSON.stringify(state)]);
    console.log(`Imported ${Object.keys(state.participants).length} participant records into PostgreSQL.`);
  }finally{await pool.end();}
})().catch(e=>{console.error(e.message);process.exitCode=1;});
