"""Append 50 intentionally accessible training items per domain to the base 600-item bank.

Items use original wording, deterministic numerical parameters and single-answer checks.
These are practice items; difficulty labels are not psychometrically calibrated.
"""
from fractions import Fraction


def append_easy(add, numeric, R, CATS):
    before = {c: 0 for c in CATS}
    def q(cat, stem, right, wrong, explanation, visual=None):
        assert len(set(map(str, [right] + list(wrong)))) == 4, (cat, stem, right, wrong)
        add(cat, stem, right, wrong, explanation, 'Easy', visual)
        before[cat] += 1
    def nq(cat, stem, answer, alternatives, explanation, unit=''):
        assert len(set(map(str,[answer] + list(alternatives)))) >= 4, (cat,stem,answer,alternatives)
        numeric(cat,stem,answer,alternatives,explanation,'Easy',unit)
        before[cat] += 1

    # Verbal reasoning: 10 analogies, 10 set inferences, 10 sequence/ordering,
    # 10 practical rule interpretations, 10 odd-one-out classification items.
    analogies = [
        ('Bird', 'Nest', 'Bee', 'Hive', ['Pond','River','Tree']),
        ('Author','Book','Painter','Painting',['Stage','Hammer','Gallery']),
        ('Clock','Time','Thermometer','Temperature',['Length','Volume','Pressure']),
        ('Carpenter','Wood','Mason','Brick',['Water','Fabric','Glass']),
        ('Key','Lock','Password','Account',['Window','Wrench','Bottle']),
        ('Teacher','Student','Doctor','Patient',['Director','Driver','Engine']),
        ('Knife','Cut','Pen','Write',['Drive','Cook','Measure']),
        ('Seed','Plant','Egg','Bird',['Stone','Rock','Cloud']),
        ('Library','Books','Museum','Artifacts',['Fuel','Cables','Invoices']),
        ('Question','Answer','Problem','Solution',['Warning','Noise','Picture']),
    ]
    for a,b,c,d,wrong in analogies:
        q(CATS[0], f'Complete the analogy: {a} is to {b} as {c} is to _____.',d,wrong,f'A {a.lower()} relates to {b.lower()} in the same way that a {c.lower()} relates to {d.lower()}.')
    triples=[('cats','mammals','animals'),('roses','flowers','plants'),('buses','vehicles','machines'),('apples','fruits','foods'),('nurses','health professionals','workers'),('triangles','polygons','shapes'),('sparrows','birds','animals'),('violins','instruments','objects'),('laptops','computers','devices'),('novels','books','publications')]
    for a,b,c in triples:
        q(CATS[0],f'All {a} are {b}. All {b} are {c}. Which statement must be true?',f'All {a} are {c}.',[f'All {c} are {a}.',f'No {a} are {c}.',f'All {b} are {a}.'],f'If {a} belong to the set of {b}, and {b} belong to {c}, then every {a[:-1] if a.endswith("s") else a} belongs to {c}.')
    people=['Amna','Bilal','Cyrus','Dina','Eman','Farah','Gita','Hassan','Iqra','Junaid']
    for i,person in enumerate(people):
        other=['Anum','Babar','Celine','Danish','Ella','Fahad','Gul','Hadi','Irfan','Javed'][i]
        q(CATS[0],f'{person} arrives before {other}. {other} arrives before the manager. Who arrives first?',person,[other,'The manager','Cannot be determined'],f'The order is {person}, then {other}, then the manager.')
    policies=[
        ('Visitors must show an entry pass before entering the site.','A visitor without an entry pass cannot enter the site.'),
        ('Every approved travel claim requires a signed receipt.','An approved travel claim must have a signed receipt.'),
        ('Only registered trainees may take the final assessment.','An unregistered trainee may not take the final assessment.'),
        ('Each completed inspection must have a dated checklist.','A completed inspection includes a dated checklist.'),
        ('All workshop attendees are required to wear badges.','Workshop attendees must wear badges.'),
        ('Every company laptop is protected with a login password.','Company laptops require a login password.'),
        ('All submitted leave requests are reviewed by a manager.','Submitted leave requests receive manager review.'),
        ('Every safety incident must be reported the same day.','Safety incidents require same-day reporting.'),
        ('Only designated staff may access the equipment room.','Staff without designation cannot access the equipment room.'),
        ('All new employees attend the induction briefing.','Every new employee attends induction.'),
    ]
    for i,(policy,conclusion) in enumerate(policies):
        q(CATS[0],f'Policy: “{policy}” Which conclusion follows?',conclusion,[
            'The policy does not apply to anyone.',
            'Following the policy is always optional.',
            'The policy applies only on weekends.'
        ],'The conclusion is a direct restatement of the stated policy.')
    groups=[
        ('Mango','Banana','Apple','Hammer'),('Monday','Tuesday','Friday','January'),
        ('Triangle','Square','Circle','Spoon'),('Litre','Metre','Kilogram','Book'),
        ('Manager','Engineer','Nurse','Motorcycle'),('Hydrogen','Oxygen','Nitrogen','Wood'),
        ('Red','Blue','Green','Loud'),('Bus','Train','Bicycle','Pillow'),
        ('Keyboard','Mouse','Monitor','Tomato'),('Doctor','Surgeon','Dentist','Cylinder'),
    ]
    for a,b,c,d in groups:
        q(CATS[0],f'Which option does NOT belong to the same general group as the others: {a}, {b}, {c}, {d}?',d,[a,b,c],f'{d} is not in the same general category as {a}, {b}, and {c}.')

    # Nonverbal, visually rendered 3x3 matrices (the last cell is omitted).
    arrows=['↑','↗','→','↘','↓','↙','←','↖']
    symbol_sets=[['▲','●','■'],['◆','★','●'],['●','✚','▲'],['■','⬟','◆'],['★','■','○']]
    for i in range(10):
        start=i%8; step=1+(i//5); rowstep=1+(i%2)
        grid=[arrows[(start+c*step+r*rowstep)%8] for r in range(3) for c in range(3)]
        ans=grid[-1];q(CATS[1],'Find the missing arrow. Follow the rotation pattern across rows and down columns.',ans,[x for x in arrows if x!=ans][:3],f'Across columns move {step*45} degrees clockwise; down rows move {rowstep*45} degrees clockwise.',grid[:-1]+['?'])
    for i in range(10):
        symbols=symbol_sets[i%5];step=1 if i<5 else 2
        grid=[symbols[(i+r+c*step)%3] for r in range(3) for c in range(3)]
        ans=grid[-1];other=[x for x in ['▲','●','■','◆','★','○','✚','⬟'] if x!=ans]
        q(CATS[1],'Which symbol completes the repeating three-symbol matrix?',ans,other[:3],'Rows and columns cycle through the same three symbols.',grid[:-1]+['?'])
    for i in range(10):
        start=i%5;step=1+(i%2);vertical=1+(i//5)
        counts=[((start+c*step+r*vertical)%5)+1 for r in range(3) for c in range(3)]
        grid=['●'*n for n in counts];ans=grid[-1];other=['●'*n for n in range(1,6) if n!=counts[-1]]
        q(CATS[1],'Choose the missing cell using the dot-count pattern (after five dots, start again at one).',ans,other[:3],'The dot counts advance consistently across columns and down rows, wrapping after five.',grid[:-1]+['?'])
    outlined=['▲','△','■','□','●','○','◆','◇']
    for i in range(10):
        start=i%8;step=1+(i%3);vertical=2+(i%2)
        grid=[outlined[(start+c*step+r*vertical)%8] for r in range(3) for c in range(3)]
        ans=grid[-1];other=[x for x in outlined if x!=ans][:3]
        q(CATS[1],'Follow the filled and outline symbol sequence. Which symbol is missing?',ans,other,'Each column and row advances a fixed number of positions through the eight-symbol cycle.',grid[:-1]+['?'])
    for i in range(10):
        symbols=['■','●','▲','◆','★','✚','⬟','○']
        start=i%8;step=1+(i//5);vertical=1+(i%3)
        grid=[symbols[(start+c*step+r*vertical)%8] for r in range(3) for c in range(3)]
        ans=grid[-1];other=[x for x in symbols if x!=ans][:3]
        q(CATS[1],'Complete the final cell in this symbol-sequence matrix.',ans,other,'The row and column movements repeat consistently across the symbol sequence.',grid[:-1]+['?'])

    # Mechanical aptitude: applied force, balanced lever, gear speed, Ohm's law, ideal pulley.
    for i in range(10):
        mass=2+i;force=mass*10
        nq(CATS[2],f'Using g = 10 m/s², approximately how much does a {mass} kg object weigh on Earth?',force,[force+10,force-10,force*2],f'Weight = mass × g = {mass} × 10 = {force} N.',' N')
    for i in range(10):
        load=40+10*i;load_arm=1+(i%3);effort_arm=2*load_arm;effort=load//2
        nq(CATS[2],f'A lever balances a {load} N load {load_arm} m from its pivot. If effort is applied {effort_arm} m from the pivot, what effort is needed?',effort,[load,load*2,effort+10],f'Balance moments: effort × {effort_arm} = {load} × {load_arm}; effort = {effort} N.',' N')
    for i in range(10):
        a=10+2*i;ratio=2+(i%3);b=a*ratio;output=20+10*i;rpm=output*ratio
        nq(CATS[2],f'A driving gear with {a} teeth rotates at {rpm} rpm and meshes with a driven gear with {b} teeth. What is the driven gear speed (magnitude)?',output,[rpm,rpm*ratio,output+30],f'Gear speeds vary inversely with teeth: {rpm} × {a}/{b} = {output} rpm.',' rpm')
    for i in range(10):
        resistance=2+i;current=1+(i%4);voltage=resistance*current
        nq(CATS[2],f'An ideal {voltage} V source powers a {resistance} Ω resistor. What is the current?',current,[current+1,current+2,current+3],f'Ohm’s law I = V/R = {voltage}/{resistance} = {current} A.',' A')
    for i in range(10):
        ropes=2+(i%4);pull=20+10*i;load=ropes*pull
        nq(CATS[2],f'An ideal pulley has {ropes} supporting rope segments and lifts a {load} N load. What minimum effort is required?',pull,[load,pull+10,pull+35],f'Ideal effort = load/number of rope segments = {load}/{ropes} = {pull} N.',' N')

    # Mathematical: arithmetic order, simple percentages, fractions, mean, speed/time.
    for i in range(10):
        a=4+i;b=3+i;c=2+(i%4);ans=a+b*c
        nq(CATS[3],f'Evaluate {a} + {b} × {c} using the standard order of operations.',ans,[a+b+c,(a+b)*c,ans+2],f'Multiplication comes first: {b} × {c} = {b*c}, then add {a}.')
    for i in range(10):
        amount=100+50*i;pct=[10,20,25,50,10,20,25,50,10,20][i];ans=amount*pct//100
        nq(CATS[3],f'What is {pct}% of {amount}?',ans,[amount,ans+10,ans+20],f'{pct}% × {amount} = {ans}.')
    for i in range(10):
        denom=[2,3,4,5,6][i%5];part=1+(i%2) if denom>2 else 1;whole=denom*(10+i);ans=part*(10+i)
        nq(CATS[3],f'What is {part}/{denom} of {whole}?',ans,[whole,ans+denom,ans+2*denom],f'{whole} ÷ {denom} × {part} = {ans}.')
    for i in range(10):
        a=10+i;b=14+i;c=18+i;ans=(a+b+c)//3
        nq(CATS[3],f'Calculate the average of {a}, {b} and {c}.',ans,[ans+2,ans-2,ans+4],f'Average = ({a}+{b}+{c})/3 = {ans}.')
    for i in range(10):
        speed=30+5*i;hours=2+(i%4);km=speed*hours
        nq(CATS[3],f'A vehicle travels at a constant {speed} km/h for {hours} hours. How far does it travel?',km,[speed+hours,km+speed,km-speed],f'Distance = speed × time = {speed} × {hours} = {km} km.',' km')

    # Focus Attention: one unambiguously correct answer, shorter codes than advanced levels.
    chars='ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
    def token(n):return ''.join(R.choice(chars) for _ in range(n))
    def swapchar(s,pos):
        ch=next(k for k in chars if k!=s[pos]);return s[:pos]+ch+s[pos+1:]
    for i in range(10):
        s=token(7+(i%3)); variants=[swapchar(s,k) for k in [0,2,len(s)-1]]
        q(CATS[4],f'Select the code that exactly matches this reference: {s}',s,variants,'Compare each character in the same position.')
    for i in range(10):
        ch='ABCDJKLMNP'[i];count=2+(i%3);sample=list(token(10));
        for j in range(len(sample)):
            if sample[j]==ch:sample[j]='Z' if ch!='Z' else 'X'
        idx=R.sample(range(len(sample)),count)
        for j in idx:sample[j]=ch
        s=''.join(sample)
        q(CATS[4],f'How many times does the character “{ch}” appear in this code: {s}?',str(count),[str(count-1),str(count+1),str(count+2)],f'The character “{ch}” appears {count} times.')
    for i in range(10):
        s=token(9);pos=i%9;changed=swapchar(s,pos)
        alt=[str(k) for k in [((pos+1)%9)+1,((pos+3)%9)+1,((pos+5)%9)+1]]
        q(CATS[4],f'The following codes differ in one position. Find that position, counting from 1. A: {s} · B: {changed}',str(pos+1),alt,f'Character {pos+1} is different.')
    for i in range(10):
        s=token(7+(i%3));answer=s[::-1];wrong=[swapchar(answer,k) for k in [0,2,len(answer)-1]]
        q(CATS[4],f'Which code is the exact reverse of {s}?',answer,wrong,f'Reading from right to left gives {answer}.')
    for i in range(10):
        s=token(9);pos=2+(i%5);dropped=s[:pos]+s[pos+1:];right=s[pos]
        wrong=R.sample([x for x in chars if x!=right],3)
        q(CATS[4],f'One character has been removed. Which character is missing? Original: {s} · Shorter: {dropped}',right,wrong,f'The missing character at position {pos+1} is {right}.')

    # Vocabulary: 50 carefully chosen common professional-English terms.
    words=[
        ('accurate','correct and free from errors'),('adapt','adjust to changed circumstances'),('allocate','assign resources for a purpose'),
        ('analyze','examine carefully to understand'),('annual','occurring once each year'),('approve','formally agree to'),
        ('assist','help someone'),('brief','short in duration or length'),('clarify','make easier to understand'),
        ('collaborate','work together'),('compare','examine similarities and differences'),('complete','finish fully'),
        ('confirm','verify as true'),('consistent','remaining steady or similar'),('coordinate','organize activities together'),
        ('critical','very important'),('deadline','the latest allowed completion time'),('decline','decrease or refuse'),
        ('delegate','assign a task to another person'),('demonstrate','show clearly with examples'),('efficient','producing results without wasted effort'),
        ('emerge','come into view'),('enhance','improve quality or value'),('essential','absolutely necessary'),
        ('evaluate','judge quality or performance'),('evidence','information supporting a conclusion'),('expand','increase in size or scope'),
        ('flexible','able to change or adapt'),('frequent','happening often'),('identify','recognize or name'),
        ('implement','put a plan into effect'),('improve','make better'),('indicate','point out or show'),
        ('influence','affect an outcome'),('inspect','examine closely'),('maintain','keep in good condition'),
        ('mandatory','required and not optional'),('objective','a goal to be achieved'),('observe','watch carefully'),
        ('obtain','get or acquire'),('priority','something requiring attention first'),('procedure','an established series of steps'),
        ('reliable','dependable and trustworthy'),('resolve','find a solution to'),('resource','something useful for a task'),
        ('schedule','a plan of activities and times'),('significant','important or large enough to matter'),
        ('temporary','lasting for a limited time'),('verify','check that something is correct'),('withdraw','remove or take back'),
    ]
    assert len(words)==50
    for i,(word,meaning) in enumerate(words):
        distractors=[words[(i+j)%50][1] for j in (11,23,37)]
        q(CATS[5],f'Choose the meaning of “{word}” in standard professional English.',meaning,distractors,f'“{word}” means {meaning}.')
    assert all(before[c]==50 for c in CATS),before
