# ProSol Assessment Arena v3 — Critical Application Review

**Assessment date:** 14 October 2026  
**Audience:** ProSol trainers, facilitators, assessment administrators and deployment engineers.  
**Reference experience:** interactive educator/presenter products such as Kahoot and Mentimeter. This is a comparison of functionality and UX patterns, not a claim of product equivalence.

## Executive Assessment

Version 3 now offers an organized workflow for six distinct tests, a nine-hundred-item question bank, strict trainer authorization before questions become visible, timed attempts, cross-browser server results, secure marking and an optional persistent cloud database. Visual consistency is substantially improved from the original version.

It is a credible **small-session assessment pilot**, but not yet an enterprise psychometric assessment platform or full Mentimeter/Kahoot substitute. The most consequential remaining gaps are verified identity, QR/PIN joining, psychometric validation, durable normalized participant-event storage, testing on real phones/browsers, and analytics/observability.

## Changes Implemented

| Component | Prior Concern | v3 Update | Current Assessment |
|---|---|---|---|
| Trainer control | Started without live trainer approval | Server-only `POST /api/admin/start`; participants wait in a lobby | Improved |
| Test availability | Easy tier missing | Exactly 50 Easy + 50 Medium + 50 Hard per category, 900 items total | Implemented; subject-review needed |
| Difficulty control | Only automatic medium/hard mixing | Explicit Easy/Medium/Hard multiselect, bounded question count and near-even selection | Improved |
| Headings | Irregular sentence case | Page H1/H2/H3 text switched to Title Case; test-question wording preserved | Updated |
| Visual design | Dense controls, inconsistent spacing | Unified light/dark tokens, polished metric cards, consistent text hierarchy, clear difficulty chips, button states and focus indicators | Improved; device QA pending |
| Participant layout | Answer text and diagrams risked clipping | Wrappable choice text, improved hit targets, 3×3 symbol matrix, compact dot-symbol styling and responsive navigation | Updated; device QA pending |
| Session time | Timeout left round logically `live`, blocking publication | Derived `closed` status when server deadline passes; results can be released afterward | Fixed and tested |
| Result reliability | Browser-local state caused missing remote answers in earlier builds | Server-authoritative registration, answers and scoring; serialized writes and rollback on errors | Fixed for one-node pilot |
| Cloud persistence | Free web hosts delete local files after restart | Optional PostgreSQL JSONB persistence via `DATABASE_URL`; production refuses unsafe local-only default | Implemented; real cloud connection pending |
| Confidentiality | Question keys previously readable by browsers in older iterations | Client receives only questions and options; answer bank/export available to authenticated trainers only | Covered by API tests |
| Export | Limited result transfer | Full historical trainer CSV and trainer-only question bank CSV | Implemented |
| Presentation | Insufficient shared context | Public live session state, link to join, group progress and optional released leaderboard | Improved |

## Admin Console — Usability Critique

**Improved:** six selectable categories; explicit difficulty levels; question count bounded to selected inventory; duration input; separate configure, authorize and publish steps; transparent lobby/live/completed states; progress, exported results and private answer review; confirmation of destructive actions.

**Still worth improving:**

1. A shareable session PIN or QR code with automated attendance and optional access expiry.
2. A searchable, pageable participant roster, and an authorized mechanism to remove/reassign incorrectly registered participants.
3. Draft/review/approve versioning for the item bank so facilitators can build sessions without editing JSON files.
4. Attendance reconciliation, verification of participant identity and rules for retakes/resume/disconnections.
5. Trainer analytics by difficulty, missed concepts, duration and question quality, not just group averages.

## Participant Console — Usability Critique

**Improved:** clear onboarding, waiting-room guidance, server-driven timer, keyboard shortcuts, 4 large choices, focus states, visual matrices, auto-saving, review tiles, completion screen and published personal score.

**Still worth improving:** device-specific accessibility/contrast checks, screen-reader review of nonverbal diagrams, confirm/undo on navigation, recovery from poor Internet, a clearer 'Offline / Reconnecting / Saved' state, verified identity and a session-resume method that works after device replacement.

**Question wording:** The question prompt is intentionally sentence case even though section headings use Title Case. Forcing Title Case onto full questions would damage readability and some proper names/formulas.

## Presentation Console — Usability Critique

**Improved:** larger session title, simple projected instructions, join URL, running clock, attendance/completion, group progress and trainer-controlled group leaderboard.

**Still worth improving:** genuine QR code generation, dynamic per-question charts, shared synchronized facilitator activities, transition animations that respect reduced-motion settings, countdown cues and optional audience anonymous polling. The design takes inspiration from Mentimeter/Kahoot but is **not** feature-equivalent.

## Data & Security Audit

**Corrected:** answer keys are not present in participant API payloads; files under `private/`, `.env` and server code are blocked by the static-file allowlist; admin password comes from environment variables; admin cookies are HTTP-only and secure in production; login attempts are rate-limited; scores are calculated on server; CSV cells are escaped; mutation queue serializes overlapping writes; failed persisted changes are rolled back; private data is not placed on the projector until released.

**Outstanding security risks:**

- Participant identity uses a full name and a bearer token on their original browser; it does not verify an employee ID, email or SSO identity. Device/token sharing is possible.
- There are no secure session PINs, mobile device binding, advanced proctoring, question-bank roles or detailed audit trails.
- The auth/session state and application cache live inside one Node process. Session tokens disappear on server restart; re-login is needed.
- Answer keys are included in the trainer/source archive. They must never be distributed as a public GitHub repository or participant download.
- A live trainer must supervise fairness and timing; no high-stakes decisions should be based solely on these generated items.

## Architecture & Hosting

### Current pilot architecture

```text
Admin Browser   ─┐
Participant(s)  ─┼─ HTTPS ─ Render Free Node.js Web Service
Presentation    ─┘                │
                           Server API + scoring
                                  │
                          DATABASE_URL (TLS)
                                  │
                     Neon / Supabase PostgreSQL
                         JSONB persisted state
```

The database replaces ephemeral web-server disk storage, but the app remains designed for **one Node.js instance and one active round**. Database writes save the whole state snapshot, not normalized answer rows. Concurrency is serialized inside that process and has been tested locally; **this is not multi-replica safe**. For a high-attendance event, remodel results as database transactions per question/participant and test network latency, connection drops and load explicitly.

### Free-tier deployment candidates (as of Oct 2026)

| Provider | Appropriate Use | Notes |
|---|---|---|
| [Neon](https://neon.com/) | **Recommended free database** | PostgreSQL; currently 1 GB per project on Free, subject to usage/compute limits. Copy pooled connection string. |
| [Render Free Web Service](https://render.com/docs/free) | **Recommended free pilot app host** | Supports Node server, managed HTTPS, possible cold starts after 15 minutes idle; local files are ephemeral. |
| [Supabase Free](https://supabase.com/pricing) | PostgreSQL alternative | 500 MB Free database, free projects can pause after a week of low activity. |
| Render Free Postgres | **Not suitable for long-lived reports** | Free Postgres instances expire after 30 days. |
| Railway Free/trial | Limited trials/demos | Trial/credit-based allowance, not a stable indefinite zero-cost guarantee. |

The `render.yaml` file declares a free web service and prompts for both `DATABASE_URL` and `ADMIN_PASSWORD` without embedding them in source code. Safeguard the credentials, keep the repository private and export daily backups of assessment results.

## Validation Report

- **900 bank items**, 150 per domain; exact **50 Easy, 50 Medium, 50 Hard** distribution validated in the bank generator.
- Every item has four distinct choices, a bounded answer key and explanatory answer text; item identifiers and complete question/diagram combinations are unique.
- **171 API HTTP checks** pass across six domains, authorization, mixing and exports.
- Additional edge-case checks pass for automatic timer expiry, score release after time runs out, **216 concurrent answer requests**, server restart result retention, and write-failure rollback.
- `node --check` syntax checks pass for the front-end script and Node server.
- **Not yet validated:** actual hosted PostgreSQL instance, physical browser/screen reader/phone QA, accessibility audits with assistive technologies, high-load conditions, and an expert evaluation of each question's psychometric validity. Local Chromium visual testing is unavailable in the current environment due to browser policy restrictions, so no claim of full visual/device testing is made.

## Prioritized Roadmap

**Priority 0, before public assessments:** test on actual Android, iPhone and laptop devices at intended venue; run with real Neon/Render deployment; export and restore real results; review all 900 items with qualified subject specialists; set an adequate password and keep keys private.

**Priority 1:** session PIN/QR, identity/attendance controls, disconnect/resume protections, remove invalid signups, normalized Postgres records and a trainer question editor.

**Priority 2:** more complete reporting (Excel/PDF and item analytics), live WebSocket/SSE charts, synchronized question projection, accessibility conformance checks, audit logs and structured incident handling.

**Priority 3:** enterprise SSO, tenant organization, roles, scheduled assessments, learning management integration, calibrated difficulty and statistical measurement validation.

**Bottom line:** v3 is a materially safer and more polished trainer-led quiz experience. It should be pilot-tested, not described as bug-free or as a validated hiring/selection exam.
