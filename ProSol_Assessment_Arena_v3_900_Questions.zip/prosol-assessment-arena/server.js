'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const ROOT = __dirname;
const DATA_FILE = process.env.ASSESSMENT_DATA_FILE || path.join(ROOT, 'data', 'assessment-state.json');
const BANK = JSON.parse(fs.readFileSync(path.join(ROOT, 'private', 'questions-bank.json'), 'utf8'));
const BANK_BY_ID = new Map(BANK.map(q => [q.id, q]));
const CATEGORIES = [...new Set(BANK.map(q => q.category))];
const GROUPS = ['Group 1', 'Group 2', 'Group 3', 'Group 4', 'Group 5'];
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
const PORT = Number(process.env.PORT || 3000);
const DATABASE_URL = process.env.DATABASE_URL || '';
const LEVELS = ['Easy','Medium','Hard'];
const COOKIE_SECURE = process.env.NODE_ENV === 'production';
if(process.env.NODE_ENV==='production' && !DATABASE_URL && process.env.ALLOW_FILE_STORAGE_IN_PRODUCTION!=='true'){
  throw new Error('Production requires DATABASE_URL for durable results. Set ALLOW_FILE_STORAGE_IN_PRODUCTION=true only with a persistent backed-up disk.');
}
if (!ADMIN_PASSWORD || ADMIN_PASSWORD.length < 12 || ADMIN_PASSWORD.includes('REPLACE_WITH')) {
  throw new Error('Configure ADMIN_PASSWORD (at least 12 characters) via .env or hosting environment.');
}
const sessions = new Map();
const loginAttempts = new Map();
const NEW_ROUND = () => ({ id: crypto.randomUUID(), phase: 'lobby', category: CATEGORIES[0], difficultyLevels: [...LEVELS], quizSize: 12, quizSeconds: 600, createdAt: new Date().toISOString(), startsAt: null, endsAt: null, resultsReleased: false });
const defaultState = () => ({ round: NEW_ROUND(), participants: {} });
const clamp = (value, min, max, fallback) => Number.isInteger(Number(value)) ? Math.min(max, Math.max(min, Number(value))) : fallback;
function loadState() {
  try {
    const saved = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    if (saved.round?.id && saved.participants && typeof saved.participants === 'object') return saved;
    // Legacy state is deliberately not silently merged because old attempts carried exposed answer keys.
    console.warn('Legacy data schema detected; retaining old file and starting an isolated session.');
    return defaultState();
  } catch (e) { if (e.code === 'ENOENT') return defaultState(); throw e; }
}
// Neon / any managed Postgres is optional; local mode keeps an atomic JSON file.
// Database mode persists the entire single-active-round snapshot in one Postgres row.
// It supports one web-server instance (pilot deployments), not multi-replica writes.
const pgPool = DATABASE_URL ? new (require('pg').Pool)({connectionString:DATABASE_URL,max:4,connectionTimeoutMillis:30000,idleTimeoutMillis:30000}) : null;
let state = defaultState();
let writes = Promise.resolve();
async function initStorage() {
  if (!pgPool) {state = loadState();return;}
  await pgPool.query(`CREATE TABLE IF NOT EXISTS prosol_app_state (id INTEGER PRIMARY KEY CHECK (id=1), payload JSONB NOT NULL, modified_at TIMESTAMPTZ NOT NULL DEFAULT NOW())`);
  await pgPool.query('INSERT INTO prosol_app_state (id,payload) VALUES (1,$1::jsonb) ON CONFLICT (id) DO NOTHING',[JSON.stringify(defaultState())]);
  const result = await pgPool.query('SELECT payload FROM prosol_app_state WHERE id=1');
  const saved = result.rows[0]?.payload;
  if(!saved?.round?.id || !saved.participants || typeof saved.participants!=='object') throw new Error('Invalid persisted assessment schema; restore from backup.');
  state = saved;
  console.log('PostgreSQL persistence connected.');
}
function persist() {
  const snapshot = JSON.stringify(state);
  writes = writes.then(async () => {
    if (pgPool) {
      const updated=await pgPool.query('UPDATE prosol_app_state SET payload=$1::jsonb, modified_at=NOW() WHERE id=1',[snapshot]);
      if(updated.rowCount!==1)throw new Error('Database state row was not updated.');
      return;
    }
    await fs.promises.mkdir(path.dirname(DATA_FILE),{recursive:true});
    const temp = `${DATA_FILE}.${crypto.randomUUID()}.tmp`;
    try {
      await fs.promises.writeFile(temp, snapshot, {encoding:'utf8',mode:0o600});
      await fs.promises.rename(temp,DATA_FILE);
    } catch(e) {await fs.promises.rm(temp,{force:true}).catch(()=>{});throw e;}
  });
  // A failed write is surfaced to the current request but must not poison future writes.
  const outcome=writes;
  writes=writes.catch(e=>{console.error('Persistence failure:',e.message);});
  return outcome;
}
function roundPhase() {
  const r=state.round;
  return r.phase==='live' && r.endsAt && Date.now()>=new Date(r.endsAt).getTime() ? 'closed' : r.phase;
}
function json(res, status, data, headers={}) {
  res.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'strict-origin-when-cross-origin',...headers});
  res.end(JSON.stringify(data));
}
function failure(message, status=400) { const e=new Error(message);e.status=status;throw e; }
async function input(req) {
  let body='';
  for await (const chunk of req) { body+=chunk; if(body.length>100_000) failure('Request too large.',413); }
  try { return body?JSON.parse(body):{}; } catch { failure('Invalid JSON body.'); }
}
function cookies(req) {
  const match=(req.headers.cookie||'').match(/(?:^|;\s*)ps_admin_session=([a-f0-9]{64})/);
  return match?.[1];
}
function isAdmin(req) {
  const token=cookies(req);
  const expires=token&&sessions.get(token);
  if(!expires||expires<Date.now()) {if(token)sessions.delete(token);return false;}
  return true;
}
function admin(req) {if(!isAdmin(req))failure('Admin login required.',401);}
function counts(roundId=state.round.id) { return Object.values(state.participants).filter(p=>p.roundId===roundId); }
function finalized(p) {return p.submittedAt!=null || (p.endsAt && Date.now()>=new Date(p.endsAt).getTime()) || p.forcedClosed===true;}
function score(p) {
  const questionIds=p.questionIds||[];
  let correct=0;
  questionIds.forEach((qid,i)=> { if (p.answers?.[i]===BANK_BY_ID.get(qid)?.answerIndex) correct++; });
  return {score:correct,total:questionIds.length,percentage:questionIds.length?Math.round(100*correct/questionIds.length):0};
}
function participantView(p) {
  const isLive=state.round.id===p.roundId && roundPhase()==='live' && !finalized(p);
  return {id:p.id,name:p.name,group:p.group,roundId:p.roundId,phase: state.round.id===p.roundId ? roundPhase() : 'closed',
    category:p.category,startedAt:p.startedAt,endsAt:p.endsAt,submitted:finalized(p),submittedAt:p.submittedAt,
    answers:p.answers||{},questions:p.questionIds?.map(id=> {const q=BANK_BY_ID.get(id);return {id:q.id,category:q.category,difficulty:q.difficulty,question:q.question,options:q.options,...(q.visualGrid?{visualGrid:q.visualGrid}:{})};})||[],
    // Answer keys and explanations never leave this server for participant endpoints.
    ...((finalized(p) && p.roundId===state.round.id && state.round.resultsReleased)?{result:score(p)}:{})};
}
function randomInt(max) {return crypto.randomInt(max);}
function shuffled(items) {const a=[...items];for(let i=a.length-1;i>0;i--){const j=randomInt(i+1);[a[i],a[j]]=[a[j],a[i]];}return a;}
function pickQuestions(category,n,levels=LEVELS) {
  const selected=levels.filter(level=>LEVELS.includes(level));
  const pools=new Map(selected.map(level=>[level,shuffled(BANK.filter(q=>q.category===category && q.difficulty===level))]));
  const result=[];
  while(result.length<n) {
    let added=false;
    for(const level of selected) {
      if(result.length===n) break;
      const item=pools.get(level)?.pop();
      if(item) {result.push(item.id);added=true;}
    }
    if(!added)failure('Not enough questions for the selected difficulty levels.',400);
  }
  return shuffled(result);
}
function publicRound() {
  const {id,category,quizSize,quizSeconds,startsAt,endsAt,resultsReleased}=state.round;
  return {id,phase:roundPhase(),category,difficultyLevels:state.round.difficultyLevels||['Medium','Hard'],quizSize,quizSeconds,startsAt,endsAt,resultsReleased,serverNow:new Date().toISOString()};
}
function publicSummary() {
  const members=counts();
  const groups=GROUPS.map(group=>{
    const people=members.filter(p=>p.group===group);
    const completed=people.filter(finalized);
    const avg=completed.length?Math.round(completed.reduce((s,p)=>s+score(p).percentage,0)/completed.length):0;
    return {group,joined:people.length,submitted:completed.length,...(state.round.resultsReleased?{average:avg}:{})};
  });
  return {round:publicRound(),joined:members.length,submitted:members.filter(finalized).length,groups};
}
function adminState() {
  const members=counts();
  return {round:publicRound(),categories:CATEGORIES,groups:GROUPS,
    countByCategory:CATEGORIES.map(category=>({category,total:BANK.filter(q=>q.category===category).length,levels:Object.fromEntries(LEVELS.map(level=>[level,BANK.filter(q=>q.category===category && q.difficulty===level).length]))})),
    participants:members.map(p=>({id:p.id,name:p.name,group:p.group,category:p.category,startedAt:p.startedAt,submittedAt:p.submittedAt,submitted:finalized(p),answered:Object.keys(p.answers||{}).length,total:p.questionIds?.length||0,score:finalized(p)?score(p):null,
      reviewAvailable:finalized(p)&&Boolean(p.questionIds?.length)})),
    summary:publicSummary(),previousRounds:[...new Set(Object.values(state.participants).filter(p=>p.roundId!==state.round.id).map(p=>p.roundId))].length};
}
function getParticipant(req,id) {
  const p=state.participants[id];
  const token=req.headers['x-participant-token'];
  if(!p||typeof token!=='string'||!crypto.timingSafeEqual(Buffer.from(crypto.createHash('sha256').update(token).digest()),Buffer.from(p.tokenHash,'hex'))) failure('Attempt not found or access denied.',403);
  return p;
}
function validOpen(p) {
  if(p.roundId!==state.round.id || roundPhase()!=='live') failure('The assessment is not active.',409);
  if(finalized(p))failure('Your assessment has ended.',409);
}
function csvEscape(v) {let s=String(v??'');if(/^[=+@-]/.test(s))s="'"+s;return '"'+s.replace(/"/g,'""')+'"';}
function adminCsv() {
  const rows=[['Name','Group','Category','Round','Status','Answered','Total','Score','Percentage','Started At','Submitted At']];
  for(const p of Object.values(state.participants)) {const s=score(p);rows.push([p.name,p.group,p.category,p.roundId,finalized(p)?'Completed':'Not completed',Object.keys(p.answers||{}).length,p.questionIds?.length||0,finalized(p)?s.score:'',finalized(p)?s.percentage:'',p.startedAt,p.submittedAt]);}
  return '\ufeff'+rows.map(row=>row.map(csvEscape).join(',')).join('\r\n');
}
async function route(req,res,u) {
  const {pathname}=u;const method=req.method;
  if(method==='GET' && pathname==='/api/health') return json(res,200,{ok:true,storage:pgPool?'postgres':'local'});
  if(method==='GET' && pathname==='/api/session') return json(res,200,publicRound());
  if(method==='GET' && pathname==='/api/summary') return json(res,200,publicSummary());
  if(method==='POST' && pathname==='/api/admin/login') {
    const ip=req.socket.remoteAddress||'unknown';const hits=(loginAttempts.get(ip)||[]).filter(x=>x>Date.now()-15*60*1000);
    if(hits.length>=10) failure('Too many login attempts. Please try again later.',429);
    const b=await input(req);
    const supplied=typeof b.password==='string'?b.password:'';
    const same=crypto.timingSafeEqual(crypto.createHash('sha256').update(supplied).digest(),crypto.createHash('sha256').update(ADMIN_PASSWORD).digest());
    if(!same) {hits.push(Date.now());loginAttempts.set(ip,hits);failure('Invalid password.',401);}
    loginAttempts.delete(ip);const token=crypto.randomBytes(32).toString('hex');sessions.set(token,Date.now()+8*3600_000);
    return json(res,200,{ok:true},{'Set-Cookie':`ps_admin_session=${token}; HttpOnly; SameSite=Strict; Path=/api; Max-Age=28800${COOKIE_SECURE?'; Secure':''}`});
  }
  if(method==='POST' && pathname==='/api/admin/logout') {const tok=cookies(req);if(tok)sessions.delete(tok);return json(res,200,{ok:true},{'Set-Cookie':`ps_admin_session=; HttpOnly; SameSite=Strict; Path=/api; Max-Age=0${COOKIE_SECURE?'; Secure':''}`});}
  if(pathname.startsWith('/api/admin/'))admin(req);
  if(method==='GET' && pathname==='/api/admin/state')return json(res,200,adminState());
  const reviewMatch=pathname.match(/^\/api\/admin\/participants\/([a-f0-9-]+)\/review$/);
  if(method==='GET' && reviewMatch){
    const p=state.participants[reviewMatch[1]];
    if(!p||p.roundId!==state.round.id||!finalized(p))failure('Review is not available.',404);
    const review=p.questionIds.map((id,i)=>{const q=BANK_BY_ID.get(id);const a=p.answers?.[i];return {question:q.question,options:q.options,answerIndex:q.answerIndex,explanation:q.explanation,given:a??null,correct:a===q.answerIndex};});
    return json(res,200,{id:p.id,name:p.name,group:p.group,score:score(p),review});
  }
  if(method==='GET' && pathname==='/api/admin/export.csv') {res.writeHead(200,{'Content-Type':'text/csv; charset=utf-8','Content-Disposition':'attachment; filename="prosol-results.csv"','Cache-Control':'no-store'});return res.end(adminCsv());}
  if(method==='GET' && pathname==='/api/admin/questions.csv') {res.writeHead(200,{'Content-Type':'text/csv; charset=utf-8','Content-Disposition':'attachment; filename="prosol-900-question-bank.csv"','Cache-Control':'no-store'});return fs.createReadStream(path.join(ROOT,'private','questions-for-trainers.csv')).pipe(res);}
  if(method==='PATCH' && pathname==='/api/admin/setup') {
    if(roundPhase()!=='lobby')failure('Prepare a new round before changing quiz settings.',409);
    const b=await input(req);
    if(!CATEGORIES.includes(b.category))failure('Select a valid category.');
    const levels=b.difficultyLevels;
    if(!Array.isArray(levels)||!levels.length||levels.length>3||new Set(levels).size!==levels.length||!levels.every(x=>LEVELS.includes(x)))failure('Select at least one valid difficulty level.');
    if(!Number.isInteger(b.quizSize)||b.quizSize<1||b.quizSize>50*levels.length)failure(`Choose 1–${50*levels.length} questions for these difficulty levels.`);
    if(!Number.isInteger(b.quizSeconds)||b.quizSeconds<60||b.quizSeconds>7200)failure('Duration must be between 1 and 120 minutes.');
    state.round.category=b.category;state.round.difficultyLevels=LEVELS.filter(x=>levels.includes(x));state.round.quizSize=b.quizSize;state.round.quizSeconds=b.quizSeconds;
    await persist();return json(res,200,{round:publicRound()});
  }
  if(method==='POST' && pathname==='/api/admin/start') {
    if(roundPhase()!=='lobby')failure('Only a prepared lobby can be started.',409);
    const members=counts();if(!members.length)failure('At least one participant must join before launch.',409);
    const now=Date.now();state.round.phase='live';state.round.startsAt=new Date(now).toISOString();state.round.endsAt=new Date(now+state.round.quizSeconds*1000).toISOString();state.round.resultsReleased=false;
    for(const p of members){p.questionIds=pickQuestions(state.round.category,state.round.quizSize,state.round.difficultyLevels);p.category=state.round.category;p.startedAt=state.round.startsAt;p.endsAt=state.round.endsAt;p.answers={};}
    await persist();return json(res,200,{round:publicRound()});
  }
  if(method==='POST' && pathname==='/api/admin/close') {
    if(roundPhase()!=='live')failure('Only a live round can be closed.',409);
    state.round.phase='closed';state.round.endsAt=new Date().toISOString();
    for(const p of counts()){if(!finalized(p)){p.forcedClosed=true;p.submittedAt=new Date().toISOString();}}
    await persist();return json(res,200,{round:publicRound()});
  }
  if(method==='POST' && pathname==='/api/admin/next') {
    if(roundPhase()==='live')failure('Close the live round before preparing the next one.',409);
    state.round=NEW_ROUND();await persist();return json(res,200,{round:publicRound()});
  }
  if(method==='PATCH' && pathname==='/api/admin/results') {
    const b=await input(req);
    if(typeof b.released!=='boolean')failure('released must be boolean.');
    if(roundPhase()==='lobby'||roundPhase()==='live')failure('Scores can only be released after the round finishes.',409);
    state.round.resultsReleased=b.released;await persist();return json(res,200,{round:publicRound()});
  }
  if(method==='POST' && pathname==='/api/participants/join') {
    if(roundPhase()!=='lobby')failure('Registration is closed. Ask your trainer to prepare a new round.',409);
    const b=await input(req);const name=String(b.name||'').trim().replace(/\s+/g,' ');const group=b.group;
    if(name.length<2||name.length>80)failure('Enter a name of 2–80 characters.');
    if(!GROUPS.includes(group))failure('Please select a valid group.');
    if(counts().some(p=>p.group===group&&p.name.toLowerCase()===name.toLowerCase()))failure('A participant with that name has already joined this group.',409);
    if(counts().length>=500)failure('Session is full (500 participants).',409);
    const id=crypto.randomUUID(),token=crypto.randomBytes(32).toString('hex');
    const p={id,roundId:state.round.id,name,group,tokenHash:crypto.createHash('sha256').update(token).digest('hex'),category:state.round.category,startedAt:null,endsAt:null,answers:{},questionIds:[],submittedAt:null};
    state.participants[id]=p;await persist();return json(res,201,{id,token,participant:participantView(p)});
  }
  const match=pathname.match(/^\/api\/participants\/([a-f0-9-]+)$/);
  if(match) {
    const p=getParticipant(req,match[1]);
    if(method==='GET')return json(res,200,{participant:participantView(p),round:publicRound()});
    if(method==='PATCH') {
      validOpen(p);const b=await input(req);
      if(!Number.isInteger(b.index)||b.index<0||b.index>=p.questionIds.length||!Number.isInteger(b.answer)||b.answer<0||b.answer>3)failure('Invalid answer submission.');
      p.answers[b.index]=b.answer;await persist();return json(res,200,{ok:true,answered:Object.keys(p.answers).length});
    }
  }
  if(method==='POST' && pathname.match(/^\/api\/participants\/[a-f0-9-]+\/submit$/)) {
    const id=pathname.split('/')[3],p=getParticipant(req,id);validOpen(p);
    if(Object.keys(p.answers).length<Math.ceil(p.questionIds.length*0.7))failure('Answer at least 70% before manual submission.',409);
    p.submittedAt=new Date().toISOString();await persist();return json(res,200,{participant:participantView(p)});
  }
  return json(res,404,{error:'API route not found.'});
}
function serveStatic(req,res,u) {
  let pathname;
  try {pathname=decodeURIComponent(u.pathname);}catch{return res.writeHead(400).end('Bad path');}
  if(pathname==='/')pathname='/index.html';
  const relative=pathname.replace(/^\/+/, '');
  const target=path.resolve(ROOT,relative);
  // Explicit allowlist: never serve trainer answer keys, credentials, backups or app source.
  const isPublicHtml=['index.html','admin.html','participant.html','console.html'].includes(relative);
  const isPublicAsset=/^assest\/(css|img|js)\/[a-zA-Z0-9_-]+\.(css|png|svg|js)$/.test(relative) && !/\/questions\./.test(relative);
  if(!target.startsWith(ROOT+path.sep) || (!isPublicHtml && !isPublicAsset))return res.writeHead(403).end('Forbidden');
  fs.stat(target,(err,stat)=>{
    if(err||!stat.isFile())return res.writeHead(404).end('Not found');
    const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.png':'image/png','.svg':'image/svg+xml'};
    res.writeHead(200,{'Content-Type':types[path.extname(target)]||'application/octet-stream','X-Content-Type-Options':'nosniff','Cache-Control':'no-cache','Referrer-Policy':'strict-origin-when-cross-origin','Content-Security-Policy':"default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'"});
    fs.createReadStream(target).pipe(res);
  });
}
let mutationQueue=Promise.resolve();
const server=http.createServer(async(req,res)=>{
  let release=null;
  let backup=null;
  const isMutation=['POST','PATCH','PUT','DELETE'].includes(req.method);
  if(isMutation){
    const previous=mutationQueue;
    mutationQueue=new Promise(resolve=>{release=resolve;});
    await previous;
    backup=structuredClone(state);
  }
  try {
    const u=new URL(req.url,'http://localhost');
    if(u.pathname.startsWith('/api/'))await route(req,res,u);
    else if(req.method==='GET')serveStatic(req,res,u);
    else json(res,405,{error:'Method not allowed.'});
  }
  catch(e){
    if(backup)state=backup;
    if(!res.headersSent){if(e.status!==401&&e.status!==403)console.error('Request error:',e.message);json(res,e.status||500,{error:e.status?e.message:'Server error.'});}
  } finally {if(release)release();}
}).on('clientError',(err,socket)=>{socket.end('HTTP/1.1 400 Bad Request\r\n\r\n');});

initStorage().then(()=>{
  // Server starts only after the persistent store is ready.
  server.listen(PORT,()=>console.log(`ProSol Arena serving on :${PORT} (${pgPool?'PostgreSQL':'local file'})`));
}).catch(error=>{console.error('Cannot initialize persistence:',error);process.exitCode=1;if(pgPool)pgPool.end().catch(()=>{});});
