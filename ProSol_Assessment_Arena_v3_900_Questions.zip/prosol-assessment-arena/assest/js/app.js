'use strict';
const PAGE=document.body.dataset.page;
const $=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const fmtTime=seconds=>{const t=Math.max(0,Math.ceil(seconds));return `${String(Math.floor(t/60)).padStart(2,'0')}:${String(t%60).padStart(2,'0')}`;};
let theme=localStorage.getItem('ps_theme')||'light';
let serverClockOffset=0;
function setTheme(value){theme=value;localStorage.setItem('ps_theme',value);document.documentElement.dataset.theme=value;const b=$('themeBtn');if(b)b.textContent=value==='dark'?'Light mode':'Dark mode';}
function notify(message){const t=$('toast');if(!t){alert(message);return;}t.textContent=message;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),4500);}
async function api(path,options={}){const requestTime=Date.now();const res=await fetch(path,{credentials:'same-origin',...options,headers:{...(options.body?{'Content-Type':'application/json'}:{}),...(options.headers||{})}});const data=await res.json().catch(()=>({}));const serverNow=data?.round?.serverNow||data?.serverNow;if(serverNow)serverClockOffset=new Date(serverNow).getTime()-(requestTime+Date.now())/2;if(!res.ok){const err=new Error(data.error||`Request failed (${res.status})`);err.status=res.status;throw err;}return data;}
function handleError(error){console.error(error);notify(error.message||'Network error. Please retry.');}
function showOnly(ids,active){ids.forEach(id=>$(id)?.classList.toggle('hidden',id!==active));}
function clockSeconds(iso){return iso?(new Date(iso).getTime()-(Date.now()+serverClockOffset))/1000:0;}
function initCommon(){setTheme(theme);$('themeBtn')?.addEventListener('click',()=>setTheme(theme==='light'?'dark':'light'));}

let adminData=null;
let lastReviewSignature='';
let adminAuth=false;
let chosenCategory=null;
let chosenLevels=new Set(['Easy','Medium','Hard']);
const levelOrder=['Easy','Medium','Hard'];
const getLevels=()=>levelOrder.filter(level=>chosenLevels.has(level));
async function refreshAdmin(){const data=await api('/api/admin/state');adminAuth=true;adminData=data;if(!chosenCategory)chosenCategory=data.round.category;renderAdmin();}
function initAdmin(){
  $('adminLoginForm').addEventListener('submit',async e=>{
    e.preventDefault();const btn=e.target.querySelector('button');btn.disabled=true;
    try{await api('/api/admin/login',{method:'POST',body:JSON.stringify({password:$('adminPass').value})});await refreshAdmin();$('adminLogin').classList.add('hidden');$('adminArea').classList.remove('hidden');$('adminLogoutBtn').classList.remove('hidden');}
    catch(err){handleError(err)}finally{btn.disabled=false;}
  });
  $('adminLogoutBtn').addEventListener('click',async()=>{try{await api('/api/admin/logout',{method:'POST'});}catch{}location.reload();});
  const run=async(method,path,body,success)=>{try{await api(path,{method,...(body?{body:JSON.stringify(body)}:{})});if(success)notify(success);chosenCategory=null;await refreshAdmin();}catch(e){handleError(e);}};
  ['settingQuestionCount','settingDuration'].forEach(id=>$(id).addEventListener('input',updateSetupState));
  document.querySelectorAll('.levelInput').forEach(input=>input.addEventListener('change',()=>{
    if(input.checked)chosenLevels.add(input.value);else chosenLevels.delete(input.value);
    const max=50*chosenLevels.size;
    const count=$('settingQuestionCount');if(max && Number(count.value)>max)count.value=max;
    updateSetupState();
  }));
  $('copyJoinLinkBtn')?.addEventListener('click',async()=>{
    const link=new URL('/participant.html',location.href).href;
    try{await navigator.clipboard.writeText(link);notify('Participant Join Link Copied.');}
    catch{notify(`Participant Join Link: ${link}`);}
  });
  $('saveSettingsBtn').addEventListener('click',()=>run('PATCH','/api/admin/setup',{category:chosenCategory,difficultyLevels:getLevels(),quizSize:Number($('settingQuestionCount').value),quizSeconds:Number($('settingDuration').value)*60},'Round Configuration Saved.'));
  $('launchBtn').addEventListener('click',async()=>{if(!confirm('Start the live assessment now? All registered participants will receive questions and a shared deadline.'))return;await run('POST','/api/admin/start',null,'Assessment Started For All Registered Participants.');});
  $('closeBtn').addEventListener('click',async()=>{if(!confirm('Close this assessment now and mark remaining attempts complete?'))return;await run('POST','/api/admin/close',null,'Round Closed.');});
  $('nextRoundBtn').addEventListener('click',async()=>{if(!confirm('Prepare a new lobby? Current results remain available in CSV export, but only the new round appears in the live dashboard.'))return;await run('POST','/api/admin/next',null,'New Waiting Lobby Prepared.');});
  $('releaseBtn').addEventListener('click',()=>run('PATCH','/api/admin/results',{released:true},'Scores Released To The Presentation Screen.'));
  $('hideBtn').addEventListener('click',()=>run('PATCH','/api/admin/results',{released:false},'Scores Hidden From Participants And Presentation Screen.'));
  $('exportBtn').addEventListener('click',()=>downloadAdmin('/api/admin/export.csv','prosol-results.csv'));
  $('downloadQuestionsBtn').addEventListener('click',()=>downloadAdmin('/api/admin/questions.csv','prosol-900-question-bank.csv'));
  refreshAdmin().then(()=>{$('adminLogin').classList.add('hidden');$('adminArea').classList.remove('hidden');$('adminLogoutBtn').classList.remove('hidden');}).catch(()=>{});
  setInterval(()=>{if(!adminAuth)return;refreshAdmin().catch(e=>{if(e.status===401){adminAuth=false;$('adminArea').classList.add('hidden');$('adminLogin').classList.remove('hidden');$('adminLogoutBtn').classList.add('hidden');notify('Admin session expired. Sign in again.');}});},3500);
  setInterval(()=>{if(adminData)adminClock();},500);
}
async function downloadAdmin(path,filename){try{const res=await fetch(path,{credentials:'same-origin'});if(!res.ok)throw new Error('Admin session expired or download unavailable.');const blob=await res.blob();const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);}catch(e){handleError(e);}}
function adminClock(){if(!adminData)return;const r=adminData.round;$('metricClock').textContent=r.startsAt?fmtTime(clockSeconds(r.endsAt)):fmtTime(r.quizSeconds);}
function updateSetupState(){
  if(!adminData)return;
  const r=adminData.round,lobby=r.phase==='lobby';
  const rawCount=Number($('settingQuestionCount').value),rawDuration=Number($('settingDuration').value);
  const maxCount=50*chosenLevels.size;
  const valid=chosenLevels.size>0&&Number.isInteger(rawCount)&&rawCount>=1&&rawCount<=maxCount&&Number.isInteger(rawDuration)&&rawDuration>=1&&rawDuration<=120;
  const savedLevels=r.difficultyLevels||['Medium','Hard'];
  const dirty=chosenCategory!==r.category||rawCount!==r.quizSize||rawDuration*60!==r.quizSeconds||JSON.stringify(getLevels())!==JSON.stringify(savedLevels);
  $('settingQuestionCount').max=Math.max(1,maxCount);
  $('availableCount').textContent=`${maxCount} Available`;
  $('levelHelp').textContent=chosenLevels.size?`${maxCount} Questions Available Across ${chosenLevels.size} Level${chosenLevels.size>1?'s':''}.`:'Select At Least One Difficulty Level.';
  document.querySelectorAll('.levelChip').forEach(label=>{
    const input=label.querySelector('input');label.classList.toggle('selected',input.checked);
    input.disabled=!lobby;
  });
  $('saveSettingsBtn').disabled=!lobby||!valid||!dirty;
  $('launchBtn').disabled=!lobby||!adminData.summary.joined||dirty||!valid;
  $('settingsNote').textContent=!lobby?'Round Settings Are Locked During The Session.':!chosenLevels.size?'Select At Least One Difficulty Level.':!valid?`Choose 1–${maxCount} Questions And 1–120 Minutes.`:dirty?'Unsaved Changes — Save Before Launching.':'All Settings Saved. Ready For Trainer Authorization.';
}
function renderAdmin(){
  if(!adminData)return;
  const d=adminData,r=d.round,live=r.phase==='live'&&clockSeconds(r.endsAt)>0,lobby=r.phase==='lobby';
  $('adminPhase').textContent=lobby?'● Registration Lobby':live?'● Assessment Live':'● Round Completed';
  $('adminPhase').className=`statusPill ${live?'live':''}`;
  $('metricJoined').textContent=d.summary.joined;$('metricDone').textContent=d.summary.submitted;$('metricQuestions').textContent=r.quizSize;
  $('metricQuestions').parentElement.querySelector('small').textContent=(r.difficultyLevels||[]).join(' · ');
  adminClock();$('roundCategory').textContent=r.category;$('roundDifficulty').textContent=(r.difficultyLevels||[]).join(', ');$('roundJoined').textContent=`${d.summary.joined} participant${d.summary.joined===1?'':'s'}`;
  $('roundPhaseText').textContent=lobby?'Waiting For Trainer Authorization':live?'Live · Responses Arriving':'Completed · Scoring Available';
  // Preserve unsaved trainer inputs while polling live status.
  if(window.lastSetupRound!==r.id){
    chosenCategory=r.category;
    chosenLevels=new Set(r.difficultyLevels||['Medium','Hard']);
    $('settingQuestionCount').value=r.quizSize;
    $('settingDuration').value=Math.round(r.quizSeconds/60);
    window.lastSetupRound=r.id;
  }
  document.querySelectorAll('.levelInput').forEach(input=>{input.checked=chosenLevels.has(input.value);});
  $('categoryCards').innerHTML=d.countByCategory.map((item,i)=>`<button type="button" class="categoryCard ${chosenCategory===item.category?'selected':''}" data-category="${esc(item.category)}" ${lobby?'':'disabled'}><span class="categoryInitial">${String(i+1).padStart(2,'0')}</span><span><strong>${esc(item.category)}</strong><small>${item.total} Questions · 3 Difficulty Levels</small></span><span class="selectionDot">${chosenCategory===item.category?'✓':''}</span></button>`).join('');
  document.querySelectorAll('.categoryCard').forEach(btn=>btn.addEventListener('click',()=>{chosenCategory=btn.dataset.category;document.querySelectorAll('.categoryCard').forEach(b=>{b.classList.toggle('selected',b===btn);b.querySelector('.selectionDot').textContent=b===btn?'✓':'';});updateSetupState();}));
  ['settingQuestionCount','settingDuration'].forEach(id=>$(id).disabled=!lobby);
  updateSetupState();
  $('closeBtn').disabled=!live;
  $('nextRoundBtn').disabled=live;
  $('releaseBtn').disabled=lobby||live;
  $('hideBtn').disabled=lobby||live;
  $('releaseText').textContent=r.resultsReleased?'Results Are Visible On The Presentation Screen.':'Scores Are Currently Private.';
  $('participantRows').innerHTML=d.participants.length?d.participants.map(p=>`<tr><td><strong>${esc(p.name)}</strong></td><td>${esc(p.group)}</td><td><span class="progressNumeric">${p.answered}/${p.total||r.quizSize}</span></td><td><span class="status ${p.submitted?'ok':(p.total?'wait':'idle')}">${p.submitted?'Completed':p.total?'In progress':'In lobby'}</span></td><td>${p.score?`${p.score.score}/${p.score.total} · ${p.score.percentage}%`:'—'}</td></tr>`).join(''):'<tr><td colspan="5" class="emptyCell">No participants registered. Share the participant page and ask everyone to join the lobby.</td></tr>';
  $('adminGroups').innerHTML=d.summary.groups.map(g=>`<div class="groupRow"><div class="groupRowHead"><strong>${esc(g.group)}</strong><span>${g.submitted}/${g.joined} completed${g.average!==undefined?` · ${g.average}% avg`:''}</span></div><div class="progressTrack"><span style="width:${g.joined?g.submitted/g.joined*100:0}%"></span></div></div>`).join('');
  // Only fetch a participant's detailed answer key after a trainer expands their review.
  const submitted=d.participants.filter(p=>p.reviewAvailable);
  const reviewSignature=JSON.stringify(submitted.map(p=>[p.id,p.answered,p.submitted,p.score?.score]));
  if(reviewSignature!==lastReviewSignature){
    lastReviewSignature=reviewSignature;
    $('adminReview').innerHTML=submitted.length?submitted.map(p=>`<details class="reviewPerson" data-person-id="${esc(p.id)}"><summary><strong>${esc(p.name)}</strong><span>${esc(p.group)} · ${p.score.score}/${p.score.total} (${p.score.percentage}%)</span></summary><div class="reviewQuestions"><p class="subtle">Open to load the private answer breakdown.</p></div></details>`).join(''):'<p class="subtle">Submitted answer breakdowns will appear here.</p>';
    $('adminReview').querySelectorAll('details[data-person-id]').forEach(details=>details.addEventListener('toggle',async()=>{
      if(!details.open||details.dataset.loaded==='true')return;
      details.dataset.loaded='true';const target=details.querySelector('.reviewQuestions');target.innerHTML='<p class="subtle">Loading answer breakdown…</p>';
      try{
        const p=await api(`/api/admin/participants/${details.dataset.personId}/review`);
        target.innerHTML=p.review.map((q,i)=>`<div class="reviewQuestion"><strong>Q${i+1}. ${esc(q.question)}</strong><p>Participant: ${q.given===null?'Not answered':`${'ABCD'[q.given]}. ${esc(q.options[q.given])}`}</p><p>Correct: ${'ABCD'[q.answerIndex]}. ${esc(q.options[q.answerIndex])}</p><small>${esc(q.explanation)}</small></div>`).join('');
      }catch(e){details.dataset.loaded='false';target.textContent=e.message;}
    }));
  }
}

let ticket=null,participant=null,participantRound=null,questionIndex=0,view='login',participantTimer=null,participantPolling=null,busyAnswer=false;
let lastQuestionRenderKey='',lastExpiryRefresh=0;
const participantViews=['participantLogin','waitingArea','quizArea','completeArea'];
const ticketKey='ps_live_ticket_v2';
function participantHeaders(){return {'X-Participant-Token':ticket?.token||''};}
async function loadParticipant(){const data=await api(`/api/participants/${ticket.id}`,{headers:participantHeaders()});participant=data.participant;participantRound=data.round;routeParticipant();}
function routeParticipant(){
  if(!participant)return;
  if(participant.submitted){showOnly(['participantLogin','waitingArea','quizArea','completeArea'],'completeArea');view='done';$('completeText').textContent=`${participant.name}, your responses for ${participant.category} have been recorded.`;
    $('participantResult').innerHTML=participant.result?`<div class="scoreReveal"><span>YOUR RESULT</span><strong>${participant.result.score} / ${participant.result.total}</strong><small>${participant.result.percentage}% correct</small></div>`:'<div class="scorePrivate">Your trainer has not released results yet.</div>';
    const nextReady=participantRound?.id!==participant.roundId&&participantRound?.phase==='lobby';
    $('joinNextRoundBtn').classList.toggle('hidden',!nextReady);
    $('nextRoundInfo').textContent=nextReady?'The trainer has opened another round. You can register again now.':'Your trainer will prepare the next round.';return;}
  if(!participant.questions.length){showOnly(['participantLogin','waitingArea','quizArea','completeArea'],'waitingArea');view='wait';$('waitingName').textContent=`${participant.name} · ${participant.group}`;$('waitingCategory').textContent=participantRound?.category||'Test category pending';$('waitingCounter').textContent='Trainer authorization pending';return;}
  showOnly(participantViews,'quizArea');view='quiz';$('quizCategory').textContent=participant.category;$('quizParticipant').textContent=`${participant.name} · ${participant.group}`;
  const renderKey=JSON.stringify([participant.roundId,participant.questions.length,participant.answers,questionIndex]);
  if(renderKey!==lastQuestionRenderKey){renderQuestion();lastQuestionRenderKey=renderKey;}
  updateParticipantClock();
}
function initParticipant(){
  const raw=localStorage.getItem(ticketKey);if(raw){try{const obj=JSON.parse(raw);if(obj.id&&obj.token)ticket=obj;}catch{}}
  $('joinNextRoundBtn').addEventListener('click',()=>{
    if(participantRound?.id===participant?.roundId||participantRound?.phase!=='lobby')return;
    localStorage.removeItem(ticketKey);ticket=null;participant=null;participantRound=null;questionIndex=0;lastQuestionRenderKey='';
    showOnly(participantViews,'participantLogin');$('joinStatus').textContent='New round open · enter your details to register.';$('joinBtn').disabled=false;
  });
  $('joinForm').addEventListener('submit',async e=>{
    e.preventDefault();const name=$('participantName').value.trim(),group=$('participantGroup').value;const btn=$('joinBtn');btn.disabled=true;
    try{const data=await api('/api/participants/join',{method:'POST',body:JSON.stringify({name,group})});ticket={id:data.id,token:data.token};localStorage.setItem(ticketKey,JSON.stringify(ticket));questionIndex=0;await loadParticipant();}catch(e){handleError(e)}finally{btn.disabled=false;}
  });
  document.addEventListener('keydown',event=>{
    if(view!=='quiz'||event.ctrlKey||event.metaKey||event.altKey||event.repeat||['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName))return;
    if(/^[1-4]$/.test(event.key)){event.preventDefault();$('optionsGrid').querySelector(`[data-answer="${Number(event.key)-1}"]`)?.click();}
    else if(event.key==='ArrowLeft'){event.preventDefault();$('prevBtn').click();}
    else if(event.key==='ArrowRight'){event.preventDefault();$('nextBtn').click();}
  });
  $('prevBtn').addEventListener('click',()=>{questionIndex=Math.max(0,questionIndex-1);renderQuestion();});
  $('nextBtn').addEventListener('click',()=>{questionIndex=Math.min(participant.questions.length-1,questionIndex+1);renderQuestion();});
  $('submitBtn').addEventListener('click',async()=>{
    if(busyAnswer||!participant)return;const answered=Object.keys(participant.answers).length;
    if(answered<Math.ceil(participant.questions.length*.7))return notify('Answer at least 70% before manually submitting.');
    if(!confirm('Submit your answers now? You will not be able to change them.'))return;
    $('submitBtn').disabled=true;
    try{const data=await api(`/api/participants/${ticket.id}/submit`,{method:'POST',headers:participantHeaders()});participant=data.participant;routeParticipant();}catch(e){handleError(e);$('submitBtn').disabled=false;}
  });
  const refresh=async()=>{if(ticket){try{await loadParticipant();}catch(e){if(e.status===403){localStorage.removeItem(ticketKey);ticket=null;participant=null;showOnly(['participantLogin','waitingArea','quizArea','completeArea'],'participantLogin');notify('This session is no longer accessible. Ask your trainer for help.');}else{console.error('Participant refresh failed:',e);}}}
    else {try{const d=await api('/api/session');$('joinStatus').textContent=d.phase==='lobby'?`Waiting lobby open · ${d.category}`:`Registration closed · ${d.phase==='live'?'assessment running':'trainer preparing next round'}`;$('joinBtn').disabled=d.phase!=='lobby';}catch{$('joinStatus').textContent='Unable to reach assessment server.';}}
  };
  refresh();participantPolling=setInterval(refresh,2300);
  participantTimer=setInterval(()=>{if(view==='quiz')updateParticipantClock();},250);
}
function updateParticipantClock(){if(!participant?.endsAt)return;const seconds=clockSeconds(participant.endsAt);$('timeLeftText').textContent=fmtTime(seconds);$('timeLeftText').parentElement.classList.toggle('urgent',seconds<=30);if(seconds<=0&&view==='quiz'&&Date.now()-lastExpiryRefresh>2000){lastExpiryRefresh=Date.now();loadParticipant().catch(()=>{});}}
function renderQuestion(){
  if(!participant||view!=='quiz'||!participant.questions.length)return;
  questionIndex=Math.max(0,Math.min(questionIndex,participant.questions.length-1));
  const q=participant.questions[questionIndex];const answered=Object.keys(participant.answers).length;
  $('questionBadge').textContent=`Question ${questionIndex+1} of ${participant.questions.length}`;$('answeredBadge').textContent=`${answered} answered`;
  $('progressFill').style.width=`${answered/participant.questions.length*100}%`;$('difficultyTag').textContent=q.difficulty;
  $('questionText').textContent=q.question;
  const visual=$('visualMatrix');if(q.visualGrid){visual.classList.remove('hidden');visual.innerHTML=q.visualGrid.map(cell=>`<div class="matrixCell ${cell==='?'?'missing':''} ${/^●{2,}$/.test(cell)?'dots':''}">${esc(cell)}</div>`).join('');}else{visual.innerHTML='';visual.classList.add('hidden');}
  $('optionsGrid').innerHTML=q.options.map((option,index)=>`<button class="answerOption ${participant.answers[questionIndex]===index?'selected':''} ${q.visualGrid?'visualOption':''}" data-answer="${index}" type="button"><span class="optionLabel">${'ABCD'[index]}</span><span class="optionContent">${esc(option)}</span>${participant.answers[questionIndex]===index?'<span class="optionCheck">✓</span>':''}</button>`).join('');
  document.querySelectorAll('.answerOption').forEach(b=>b.addEventListener('click',async()=>{
    if(busyAnswer||clockSeconds(participant.endsAt)<=0)return;
    const idx=questionIndex,answer=Number(b.dataset.answer);busyAnswer=true;$('saveStatus').textContent='Saving answer…';
    try{await api(`/api/participants/${ticket.id}`,{method:'PATCH',headers:participantHeaders(),body:JSON.stringify({index:idx,answer})});participant.answers[idx]=answer;$('saveStatus').textContent='Answer saved';renderQuestion();}
    catch(e){$('saveStatus').textContent='Save failed – select again';handleError(e);if(e.status===409)await loadParticipant();}finally{busyAnswer=false;}
  }));
  $('reviewGrid').innerHTML=participant.questions.map((_,i)=>`<button type="button" data-index="${i}" class="numberTile ${participant.answers[i]!==undefined?'answered':''} ${i===questionIndex?'active':''}" aria-label="Question ${i+1}${participant.answers[i]!==undefined?' answered':''}">${i+1}</button>`).join('');
  document.querySelectorAll('.numberTile').forEach(b=>b.addEventListener('click',()=>{questionIndex=Number(b.dataset.index);renderQuestion();}));
  $('prevBtn').disabled=questionIndex===0;$('nextBtn').disabled=questionIndex===participant.questions.length-1;
  lastQuestionRenderKey=JSON.stringify([participant.roundId,participant.questions.length,participant.answers,questionIndex]);
  const need=Math.ceil(.7*participant.questions.length);$('submitBtn').disabled=answered<need;
  $('submitHint').textContent=answered<need?`Answer at least ${need} of ${participant.questions.length} questions to unlock manual submission (${answered} recorded).`:'You may submit now, or review your answers before time ends.';
}

function initConsole(){
  $('presentationJoinLink').textContent=new URL('/participant.html',location.href).href;
  const render=async()=>{try{const {round,joined,submitted,groups}=await api('/api/summary');
    const live=round.phase==='live'&&clockSeconds(round.endsAt)>0;
    $('consolePhase').textContent=round.phase==='lobby'?'REGISTRATION OPEN':live?'ASSESSMENT IN PROGRESS':'ROUND FINISHED';
    $('consoleCategory').textContent=round.category;$('consoleDescription').textContent=round.phase==='lobby'?'Participants may join the lobby. Assessment begins only when the trainer launches it.':live?'Participants are completing their assessments across devices.':'The session has ended. Results are trainer-controlled.';
    $('consoleJoined').textContent=joined;$('consoleSubmitted').textContent=submitted;$('consoleQuestionCount').textContent=round.quizSize;
    $('consoleClock').textContent=live?fmtTime(clockSeconds(round.endsAt)):round.phase==='lobby'?fmtTime(round.quizSeconds):'00:00';
    $('consoleGroups').innerHTML=groups.map(g=>`<div class="groupRow"><div class="groupRowHead"><strong>${esc(g.group)}</strong><span>${g.submitted} / ${g.joined} completed</span></div><div class="progressTrack"><span style="width:${g.joined?g.submitted/g.joined*100:0}%"></span></div></div>`).join('');
    $('consoleRankTitle').textContent=round.resultsReleased?'Released Group Leaderboard':'Participant Guidance';
    $('consoleResults').innerHTML=round.resultsReleased?groups.filter(g=>g.submitted>0).sort((a,b)=>b.average-a.average).map((g,i)=>`<div class="leaderRow"><span class="leaderRank">${String(i+1).padStart(2,'0')}</span><strong>${esc(g.group)}</strong><span class="leaderScore">${g.average}%</span></div>`).join('')||'<p class="subtle">Results are released; no completed submissions yet.</p>':'<div class="guidelines"><p>01 · Enter your full name and assigned group.</p><p>02 · Wait until the trainer authorizes the test.</p><p>03 · Complete the questions within the shared time limit.</p><p>04 · Scores remain private until released.</p></div>';
  }catch(e){console.error(e);notify('Presentation screen could not refresh.');}};
  render();setInterval(render,2400);
  $('fullscreenBtn').addEventListener('click',()=>{if(!document.fullscreenElement)document.documentElement.requestFullscreen?.();else document.exitFullscreen?.();});
}
initCommon();if(PAGE==='admin')initAdmin();if(PAGE==='participant')initParticipant();if(PAGE==='console')initConsole();
