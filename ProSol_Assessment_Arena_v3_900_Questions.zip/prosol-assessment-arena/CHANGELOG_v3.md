# What's New In Version 3.0

- Added **300 Easy questions** (50 per category); six subjects now each contain 150 questions.
- Trainer may select any of the **Easy / Medium / Hard** difficulty levels and configure 1–150 items as available.
- Updated all static section headings to Title Case; refreshed navy/teal palette, panel spacing, selected states, focus indicators and mobile quiz text wrapping.
- Fixed timed-out rounds incorrectly remaining live, including blocked results publication after expiry.
- Added serialized state mutation, write-failure rollback and optional Neon/Supabase-compatible PostgreSQL persistence.
- Added production guard against ephemeral local-result storage and an example Render `render.yaml`.
- Expanded tests covering concurrency, failure recovery, timeout behavior and database adapter startup.
- Updated help documentation and critical UX / architecture review.

The current product remains a pilot experience. It is not a validated psychometric exam, full Mentimeter/Kahoot equivalent or proven bug-free across real hosted environments.
